/*----------------------------------------------------------------------------*/
/* Total Harmonic Distortion                                                  */
/*----------------------------------------------------------------------------*/
#define HELP_MSG \
"This example simulates a simple harmonic analysis of a nonlinear system\n\
using HarmonicAnalyzer().  In this example, a pure sinusoid with a given\n\
fundamental frequency is generated and then passed to your system.  The\n\
nonlinearly-distorted output of 'Your System' is windowed and the\n\
AutoPowerSpectrum is computed and passed to the HarmonicAnalyzer function.\n\
\n\
Cursors are positioned to display the fundamental and harmonic frequencies,\n\
while the Total Harmonic Distortion and the THD + Noise are computed and\n\
displayed."

/*----------------------------------------------------------------------------*/
/* Includes                                                                   */
/*----------------------------------------------------------------------------*/
#include <utility.h>
#include <userint.h>
#include <analysis.h>
#include <ansi_c.h>

#include "thd.h"

/*----------------------------------------------------------------------------*/
/* Variables                                                                  */
/*----------------------------------------------------------------------------*/
static int panelHandle;
                        
/*----------------------------------------------------------------------------*/
/* Main                                                                       */
/*----------------------------------------------------------------------------*/
int main (int argc, char *argv[])
{
    if (InitCVIRTE (0, argv, 0) == 0)
        return -1;  /* out of memory */
    if ((panelHandle = LoadPanel (0, "thd.uir", PANEL)) < 0)
        return -1;
        
    DisplayPanel (panelHandle);
    RunUserInterface ();
    DiscardPanel (panelHandle);
    return 0;
}

/*----------------------------------------------------------------------------*/
/* CalculateTHD                                                               */
/*----------------------------------------------------------------------------*/
static int CalculateTHD(void)
{
    WindowConst window_constants;
    double fundamental_frequency;
    double sampling_rate;
    int frame_size;
    int window_type;
    int number_of_harmonics;
    
    int i;
    int err;
    
    double frequency;
    double phase = 0.0;
    double df;
    double *sine_wave;
    double *noise;
    double *distored_signal;
    double *auto_power_spectrum;
    double *x_axis;
    double *harmonic_amplitudes;
    double *harmonic_frequencies;
    double thd;
    double thdnoise;

    /* Get values from */
    err = DeleteGraphPlot (panelHandle, PANEL_APSGRAPH, -1, VAL_IMMEDIATE_DRAW);
    GetCtrlVal (panelHandle, PANEL_FUNDFREQ, &fundamental_frequency);
    GetCtrlVal (panelHandle, PANEL_RATE, &sampling_rate);
    GetCtrlVal (panelHandle, PANEL_FRAMESIZE, &frame_size);
    GetCtrlVal (panelHandle, PANEL_WINDOWTYPE, &window_type);

    sine_wave = (double *)malloc(frame_size*sizeof(double));
    if(sine_wave == NULL) {
                            return OutOfMemAnlysErr;
                          }
    frequency = fundamental_frequency/sampling_rate;
    err = SineWave (frame_size, 1.0, frequency, &phase, sine_wave);
    if(err != NoAnlysErr) {
                        free(sine_wave);
                        return err;
                     }
    noise = (double *)malloc(frame_size*sizeof(double));
    if(noise ==  NULL) {
                            free(sine_wave);
                            return OutOfMemAnlysErr;
                       }
    err = WhiteNoise (frame_size, 0.1, -1, noise);
    if(err != NoAnlysErr) {
                        free(sine_wave);
                        free(noise);
                        return err;
                     }
    distored_signal = (double *)malloc(frame_size*sizeof(double));
    if(distored_signal == NULL) {
                                    free(sine_wave);
                                    free(noise);
                                    return OutOfMemAnlysErr;
                                }
    for(i = 0; i < frame_size; i++)
        *(distored_signal + i) = *(sine_wave+i) + (*(sine_wave+i) * *(sine_wave+i) * 0.5)
                                 + *(noise+i);
    err = ScaledWindow (distored_signal, frame_size, window_type, &window_constants);
    if(err != NoAnlysErr) {
                            free(sine_wave);
                            free(noise);
                            free(distored_signal);
                            return err;
                          }

    auto_power_spectrum = (double *)malloc((frame_size/2)*sizeof(double));
    if(auto_power_spectrum == NULL) {
                                        free(sine_wave);
                                        free(noise);
                                        free(distored_signal);
                                        return OutOfMemAnlysErr;
                                    }
        
    err = AutoPowerSpectrum (distored_signal, frame_size, 1.0/sampling_rate,
                            auto_power_spectrum, &df);
    if(err != NoAnlysErr) {
                        free(sine_wave);
                        free(noise);
                        free(distored_signal);
                        return err;
                    }
    x_axis = (double *)malloc((frame_size/2)*sizeof(double));
    if(x_axis == NULL) {
                            free(sine_wave);
                            free(noise);
                            free(distored_signal);
                            return err;
                        }
                        
    for(i = 0; i < (frame_size/2); i++) *(x_axis + i) = i * df;

    PlotXY (panelHandle, PANEL_APSGRAPH, x_axis, auto_power_spectrum,
            frame_size/2, VAL_DOUBLE, VAL_DOUBLE, VAL_THIN_LINE,
            VAL_EMPTY_SQUARE, VAL_SOLID, 1, VAL_RED);

    GetCtrlVal(panelHandle,PANEL_HARMONICS, &number_of_harmonics);

    harmonic_amplitudes = (double *)malloc(number_of_harmonics * sizeof(double));
    if(harmonic_amplitudes == NULL){
                                        free(sine_wave);
                                        free(noise);
                                        free(distored_signal);
                                        return OutOfMemAnlysErr;
                                    }

    harmonic_frequencies = (double *)malloc(number_of_harmonics * sizeof(double));
    if(harmonic_frequencies == NULL){
                                        free(sine_wave);
                                        free(noise);
                                        free(distored_signal);
                                        free(harmonic_amplitudes);
                                        return OutOfMemAnlysErr;
                                     }
                                    
    err = HarmonicAnalyzer(auto_power_spectrum, frame_size/2, frame_size, number_of_harmonics, 
                           window_type, sampling_rate, fundamental_frequency, 
                           harmonic_amplitudes, harmonic_frequencies, &thd, &thdnoise);
    if(err != NoAnlysErr) {
                        free(sine_wave);
                        free(noise);
                        free(distored_signal);
                        free(harmonic_amplitudes);
                        free(harmonic_frequencies);
                        return err;
                     }
                 

    SetCtrlAttribute (panelHandle, PANEL_APSGRAPH, ATTR_NUM_CURSORS,
          number_of_harmonics);

    for(i = 0; i < number_of_harmonics; i++)
    {
        int BOLE;
        SetCursorAttribute (panelHandle, PANEL_APSGRAPH, i+1, ATTR_CURSOR_POINT_STYLE,
            VAL_SOLID_CIRCLE);
        SetCursorAttribute (panelHandle, PANEL_APSGRAPH, i+1, ATTR_CROSS_HAIR_STYLE,
            VAL_VERTICAL_LINE);
        SetCursorAttribute (panelHandle, PANEL_APSGRAPH, i+1, ATTR_CURSOR_COLOR,
            VAL_BLUE);
        SetActiveGraphCursor (panelHandle, PANEL_APSGRAPH, i+1);
        BOLE = SetBreakOnLibraryErrors (0);
        SetGraphCursor (panelHandle, PANEL_APSGRAPH, i+1, *(harmonic_frequencies+i),
                    (*(harmonic_amplitudes+i) * *(harmonic_amplitudes+i)));
        SetBreakOnLibraryErrors (BOLE);
    }

    SetCtrlVal(panelHandle,PANEL_THD, thd);
    SetCtrlVal(panelHandle,PANEL_THDNOISE, thdnoise);
    
    free(sine_wave);
    free(noise);
    free(distored_signal);
    free(harmonic_amplitudes);
    free(harmonic_frequencies);
	free(auto_power_spectrum);
	free(x_axis);
    return 0;
}   

/*----------------------------------------------------------------------------*/
/* RunCalculation                                                             */
/*----------------------------------------------------------------------------*/
int CVICALLBACK RunCalculation (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) 
    {
        case EVENT_COMMIT:
            CalculateTHD();
            
            break;
    }
    return 0;
}

/*----------------------------------------------------------------------------*/
/* Quit                                                                       */
/*----------------------------------------------------------------------------*/
int CVICALLBACK Quit (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            QuitUserInterface (0);
            break;
    }
    return 0;
}

/*----------------------------------------------------------------------------*/
/* Help                                                                       */
/*----------------------------------------------------------------------------*/
int CVICALLBACK Help (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_RIGHT_CLICK:
        case EVENT_COMMIT:
            MessagePopup ("Total Harmonic Distortion Example",HELP_MSG);
        break;
    }
    return 0;
}


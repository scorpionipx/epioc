/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                           1
#define  PANEL_SIZE                      2
#define  PANEL_DELAY_X                   3
#define  PANEL_WIDTH_X                   4
#define  PANEL_DELAY_Y                   5
#define  PANEL_WIDTH_Y                   6
#define  PANEL_G0                        7       /* callback function: Go */
#define  PANEL_HELP                      8       /* callback function: Help */
#define  PANEL_QUIT                      9       /* callback function: Quit */
#define  PANEL_IMAGE                     10
#define  PANEL_2DFFT                     11
#define  PANEL_CALCULATING               12
#define  PANEL_DECORATION                13
#define  PANEL_TEXTMSG                   14


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */ 

int  CVICALLBACK Go(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Help(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Quit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif

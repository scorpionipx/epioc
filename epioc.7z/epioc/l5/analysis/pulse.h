/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                           1
#define  PANEL_Demo                      2       /* callback function: DemoCallback */
#define  PANEL_Help                      3       /* callback function: HelpCallback */
#define  PANEL_ACQ                       4       /* callback function: Acquire */
#define  PANEL_STOPACQ                   5       /* callback function: StopAcq */
#define  PANEL_GRAPH                     6
#define  PANEL_NINETY                    7
#define  PANEL_FIFTY                     8
#define  PANEL_TEN                       9
#define  PANEL_BASE                      10
#define  PANEL_TOP                       11
#define  PANEL_SLEW                      12
#define  PANEL_FALL                      13
#define  PANEL_RISE                      14
#define  PANEL_WIDTH                     15
#define  PANEL_DELAY                     16
#define  PANEL_UNDER                     17
#define  PANEL_OVER                      18
#define  PANEL_AMP                       19
#define  PANEL_STOP                      20      /* callback function: Stop */
#define  PANEL_LOOP                      21      /* callback function: Main_Loop */
#define  PANEL_DISPLAYMSG                22
#define  PANEL_DECORATION                23


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */ 

int  CVICALLBACK Acquire(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK DemoCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK HelpCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Main_Loop(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Stop(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK StopAcq(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif

/*****************************************************************/
/*                                                               */
/*  Pulse Function Example Program                               */
/*  National Instruments                                         */
/*  August, 1995                                                 */
/*                                                               */
/*****************************************************************/
#define HELP_MSG \
"This program serves as an example use of the PulseParam function\n\
in the Advanced Analysis library.  Choose the Aquire button to\n\
start a recording.  Then create a pulse waveform by dragging\n\
the graph cursor from left to right.  When you are done, stop the\n\
acquisition by choosing the Stop Aquiring button.  Data returned\n\
from the Pulse function will be displayed on the right area of the\n\
display."

#include <cvirte.h>     /* needed if linking executable in external compiler; harmless otherwise */
#include <utility.h>
#include <analysis.h>
#include <userint.h>
#include "pulse.h"

static int panelHandle;
double pulsebuf[101];
int go=0;

void CleanBuffer(void);
void AnalyzeBuffer(void);  

int main (int argc, char *argv[])
{
    if (InitCVIRTE (0, argv, 0) == 0)    /* Needed if linking in external compiler; harmless otherwise */
        return -1;    /* out of memory */
    
    if ((panelHandle = LoadPanel (0, "pulse.uir", PANEL)) < 0)
        return -1;
	
	SetCtrlAttribute (panelHandle, PANEL_FALL, ATTR_DATA_TYPE, VAL_SSIZE_T);
	SetCtrlAttribute (panelHandle, PANEL_RISE, ATTR_DATA_TYPE, VAL_SSIZE_T);
	SetCtrlAttribute (panelHandle, PANEL_WIDTH, ATTR_DATA_TYPE, VAL_SSIZE_T);
	SetCtrlAttribute (panelHandle, PANEL_DELAY, ATTR_DATA_TYPE, VAL_SSIZE_T);
	
    SetCtrlAttribute (panelHandle, PANEL_STOPACQ, ATTR_DIMMED, 1);
    SetCtrlAttribute (panelHandle, PANEL_ACQ, ATTR_DIMMED, 0); 
    SetCtrlAttribute (panelHandle, PANEL_DISPLAYMSG, ATTR_VISIBLE, 0);

    DisplayPanel (panelHandle);
    RunUserInterface ();
    DiscardPanel (panelHandle);
    return 0;
}

int CVICALLBACK Acquire (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    static int i;
    
    switch (event) {
        case EVENT_COMMIT:
            /* Display message */
            SetCtrlVal(panelHandle, PANEL_DISPLAYMSG, "Create a pulse waveform by\ndragging the graph cursor.\nChoose Stop Acquiring when done.");
            SetCtrlAttribute (panelHandle, PANEL_DISPLAYMSG, ATTR_VISIBLE, 1);
            
            go=1;
            SetCtrlAttribute (panelHandle, PANEL_STOPACQ, ATTR_DIMMED, 0);
            SetCtrlAttribute (panelHandle, PANEL_ACQ, ATTR_DIMMED, 1);
            DeleteGraphPlot (panelHandle, PANEL_GRAPH, -1,
                             VAL_IMMEDIATE_DRAW);
            SetGraphCursor (panelHandle, PANEL_GRAPH, 1, 0.0, 0.0);
            for(i=0;i<101;i++) pulsebuf[i]=999; /* init pulse buffer */
            break;
    }
    return 0;
}

int CVICALLBACK StopAcq (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{

    switch (event) {
        case EVENT_COMMIT:
            go=0;
            SetCtrlAttribute (panelHandle, PANEL_STOPACQ, ATTR_DIMMED, 1);
            SetCtrlAttribute (panelHandle, PANEL_ACQ, ATTR_DIMMED, 0);
            CleanBuffer();
            
            PlotWaveform (panelHandle, PANEL_GRAPH, pulsebuf, 101,
                          VAL_DOUBLE, 1.0, 0.0, 0.0, 1.0, VAL_FAT_LINE,
                          VAL_SOLID_CIRCLE, VAL_SOLID, 1, VAL_DK_GREEN);
                
            AnalyzeBuffer();
            
            SetCtrlAttribute (panelHandle, PANEL_DISPLAYMSG, ATTR_VISIBLE, 0);
            break;
    }
    return 0;
}

int CVICALLBACK Main_Loop (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    static double xval,yval;
    static int xint;
    
    switch (event) {
        case EVENT_TIMER_TICK:
            if(go)
            {
                GetGraphCursor (panelHandle, PANEL_GRAPH, 1, &xval, &yval);
                xint=(int)xval;
                if(xint<0) xint=0;
                pulsebuf[xint]=yval;
                PlotPoint (panelHandle, PANEL_GRAPH, xval, yval,
                           VAL_SOLID_SQUARE, VAL_DK_BLUE);
                
            }
            break;
    }
    return 0;
}

int CVICALLBACK Stop (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            QuitUserInterface (0);
            break;
    }
    return 0;
}

void CleanBuffer(void)
{
  int index, locate, i;
  int dx;
  double dy, step;
  
  if(pulsebuf[0]==999) pulsebuf[0]=0;   /* Must have a starting point */
 
  for(index=0;index<101;index++)
    if(pulsebuf[index]==999)                /* found a hole */
    {
        locate=index;
        while((pulsebuf[locate]==999)&&(locate<100))   /* find end of hole */
            locate++;
        if(locate==100)                 /* does hole go to end? */
            for(i=index;i<101;i++) pulsebuf[i]= pulsebuf[index-1];
        else
        {
            dx=locate-(index-1);
            dy=pulsebuf[locate]-pulsebuf[index-1];
            step=dy/dx;
            for(i=index;i<locate;i++)
                pulsebuf[i]=pulsebuf[i-1]+step;
        }
        
    }
  
    
}
void AnalyzeBuffer(void)
{
    int i, color;
    static double slew;
    static ssize_t fall;
    static ssize_t rise;
    static ssize_t width;
    static ssize_t delay;
    static double under;
    static double over;
    static double base;
    static double top;
    static double ten;
    static double fifty;
    static double ninety;
    static double amp;

    PulseParam (pulsebuf, 101, &amp, &ninety, &fifty, &ten, &top,
            &base, &over, &under, &delay, &width, &rise, &fall,
            &slew);
            
    SetCtrlVal (panelHandle, PANEL_AMP, amp);
    SetCtrlVal (panelHandle, PANEL_NINETY, ninety);
    SetCtrlVal (panelHandle, PANEL_FIFTY, fifty);
    SetCtrlVal (panelHandle, PANEL_TEN, ten);
    SetCtrlVal (panelHandle, PANEL_TOP, top);
    SetCtrlVal (panelHandle, PANEL_BASE, base);
    SetCtrlVal (panelHandle, PANEL_OVER, over);
    SetCtrlVal (panelHandle, PANEL_UNDER, under);
    SetCtrlVal (panelHandle, PANEL_DELAY, delay);
    SetCtrlVal (panelHandle, PANEL_WIDTH, width);
    SetCtrlVal (panelHandle, PANEL_RISE, rise);
    SetCtrlVal (panelHandle, PANEL_FALL, fall);
    SetCtrlVal (panelHandle, PANEL_SLEW, slew);
    
    GetCtrlAttribute (panelHandle, PANEL_DECORATION, ATTR_FRAME_COLOR, &color);
    for (i=0;i<2;i++) {
        SetCtrlAttribute (panelHandle, PANEL_DECORATION, ATTR_FRAME_COLOR, VAL_RED); SyncWait (Timer(), 0.25); ProcessDrawEvents();
        SetCtrlAttribute (panelHandle, PANEL_DECORATION, ATTR_FRAME_COLOR, color);   SyncWait (Timer(), 0.25); ProcessDrawEvents();
    }    
}

/*****************************************************************/
/*                                                               */
/* Help Button Callback                                          */
/*                                                               */
/*****************************************************************/
int CVICALLBACK HelpCallback (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_RIGHT_CLICK:
        case EVENT_COMMIT:
            MessagePopup ("Correlation Function Example Program",HELP_MSG);
        break;
    }
    return 0;
}

int CVICALLBACK DemoCallback (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    double noise[100];
    int i;
    
    switch (event) {
        case EVENT_COMMIT:
            DeleteGraphPlot (panelHandle, PANEL_GRAPH, -1, VAL_IMMEDIATE_DRAW);
                             
            /* Display message */
            SetCtrlVal(panelHandle, PANEL_DISPLAYMSG, "Plotting a series of\npoints to represent\n a pulsed signal");
            SetCtrlAttribute (panelHandle, PANEL_DISPLAYMSG, ATTR_VISIBLE, 1);
            
            /* Draw Points */
            Set1D (pulsebuf, 100, 0.0);
            Ramp (5, 0.0, 45, &pulsebuf[5]);
            Set1D (&pulsebuf[10], 5, 45);
            Ramp (5, 45, 0, &pulsebuf[15]);
            WhiteNoise (100, 1.0, 0, noise);
            Add1D (pulsebuf, noise, 100, pulsebuf);

            for (i=0;i<101;i=i+3) {
                PlotPoint (panelHandle, PANEL_GRAPH, (double)i, pulsebuf[i],
                           VAL_SOLID_SQUARE, VAL_DK_BLUE);
                ProcessDrawEvents();
                SyncWait (Timer(), 0.1);
            }    
            
            SyncWait (Timer(), 1);
            
            PlotWaveform (panelHandle, PANEL_GRAPH, pulsebuf, 101,
                          VAL_DOUBLE, 1.0, 0.0, 0.0, 1.0, VAL_FAT_LINE,
                          VAL_SOLID_CIRCLE, VAL_SOLID, 1, VAL_DK_GREEN);
                
            SetCtrlVal(panelHandle, PANEL_DISPLAYMSG, "Generating and displaying the\nPulseParam data");
            ProcessDrawEvents();
            
            /* Analyze Pulse */
            AnalyzeBuffer();
                        
            SyncWait (Timer(), 3);
            
            break;
    }
    return 0;
}


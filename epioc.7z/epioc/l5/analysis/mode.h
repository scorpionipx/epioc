/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                           1
#define  PANEL_PLOT                      2       /* callback function: Plot */
#define  PANEL_HELP                      3       /* callback function: HelpCallback */
#define  PANEL_QUIT                      4       /* callback function: Shutdown */
#define  PANEL_GRAPH                     5
#define  PANEL_MODE                      6
#define  PANEL_INTERVALS                 7
#define  PANEL_Data0                     8
#define  PANEL_Data1                     9
#define  PANEL_Data2                     10
#define  PANEL_Data3                     11
#define  PANEL_Data4                     12
#define  PANEL_HISTMAX                   13
#define  PANEL_HISTMIN                   14
#define  PANEL_DECORATION                15
#define  PANEL_TEXTMSG                   16
#define  PANEL_TEXTMSG_2                 17


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */ 

int  CVICALLBACK HelpCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Plot(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Shutdown(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif

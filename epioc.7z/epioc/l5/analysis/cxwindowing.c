/*****************************************************************/
/*                                                               */
/* Complex Signal Windowing Example Program                      */
/*                                                               */
/*****************************************************************/
#define HELP_MSG \
"This program is designed to serve as an example in how to use \n\
window functions with complex signals. This program combines \n\
two sinusoidal waveforms as the real and imaginary parts of the \n\
complex signal. The complex windowing functions provide a \n\
straightforward and simple way to perform the equivalent of \n\
windowing the real and imaginary parts of the complex signal \n\
separately. "

#include <cvirte.h>     /* needed if linking executable in external compiler; harmless otherwise */
#include <utility.h>
#include <ansi_c.h>
#include <analysis.h>
#include <userint.h>
#include "cxwindowing.h"
#include "toolbox.h"  

#define NUMPOINTS 1024

static int panelHandle;
static double waveTime[2][NUMPOINTS];
static double window[NUMPOINTS];
static NIComplexNumber tempArray[NUMPOINTS];
static double spectrum[NUMPOINTS];


void RedrawCalcAndDrawGraphs(void);

/****************************************************************/
/*                                                              */
/* Main Routine                                                 */
/*                                                              */
/****************************************************************/

int main (int argc, char *argv[])
{
    if (InitCVIRTE (0, argv, 0) == 0)    /* Needed if linking in external compiler; harmless otherwise */
        return -1;    /* out of memory */
    
    if ((panelHandle = LoadPanel (0, "cxwindowing.uir", PANEL)) < 0)
        return -1;
    
    RedrawCalcAndDrawGraphs();
    
    DisplayPanel (panelHandle);
    RunUserInterface ();
	DiscardPanel (panelHandle);
    return 0;
}


/****************************************************************/
/*                                                              */
/* Recalculate the Output Graphs                                */
/*                                                              */
/****************************************************************/
int CVICALLBACK RecalcWaveforms (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
                RedrawCalcAndDrawGraphs();
            break;
    }
    return 0;
}


/****************************************************************/
/*                                                              */
/* Recalculate the Output Graphs                                */
/*                                                              */
/****************************************************************/
void RedrawCalcAndDrawGraphs(void)
{
    double waveIAmp, waveQAmp, waveIFreq, waveQFreq, freqSpace;
    int windowing;
    int scaling, i, j;
    WindowConst constants;
    double zero = 0.0;
	int currPlotHandle;

    /* Clear Plots */    
    DeleteGraphPlot (panelHandle, PANEL_FREQGRAPH,   -1, VAL_DELAYED_DRAW);
    DeleteGraphPlot (panelHandle, PANEL_TIMEGRAPH,   -1, VAL_DELAYED_DRAW);
    DeleteGraphPlot (panelHandle, PANEL_WINDOWGRAPH, -1, VAL_DELAYED_DRAW);
    
    /* Get User Inputs */    
    GetCtrlVal (panelHandle, PANEL_WAVE1AMP,    &waveIAmp);
    GetCtrlVal (panelHandle, PANEL_WAVE2AMP,    &waveQAmp);
    GetCtrlVal (panelHandle, PANEL_WAVE1FREQ,   &waveIFreq);
    GetCtrlVal (panelHandle, PANEL_WAVE2FREQ,   &waveQFreq);
    GetCtrlVal (panelHandle, PANEL_SCALE,       &scaling);
    GetCtrlVal (panelHandle, PANEL_DATAWINDOW,  &windowing);

    /* Generate I/Q Signals */
    SineWave (NUMPOINTS, waveIAmp, waveIFreq/500, &zero, waveTime[0]);
    SineWave (NUMPOINTS, waveQAmp, waveQFreq/500, &zero, waveTime[1]);
    
    /* Combine I/Q Signals and Display */
    for (i=0;i<NUMPOINTS;i++) {
		tempArray[i].real = waveTime[0][i];
		tempArray[i].imaginary = waveTime[1][i];
	}
	
    currPlotHandle = PlotY (panelHandle, PANEL_TIMEGRAPH, waveTime[0], (NUMPOINTS/100)*20+1,
           VAL_DOUBLE, VAL_THIN_LINE, VAL_NO_POINT, VAL_SOLID, 1, VAL_RED);
	SetPlotAttribute (panelHandle, PANEL_TIMEGRAPH, currPlotHandle, ATTR_PLOT_LG_TEXT, "I Signal");
	
	currPlotHandle = PlotY (panelHandle, PANEL_TIMEGRAPH, waveTime[1], (NUMPOINTS/100)*20+1,
           VAL_DOUBLE, VAL_THIN_LINE, VAL_NO_POINT, VAL_SOLID, 1, VAL_BLUE);
	SetPlotAttribute (panelHandle, PANEL_TIMEGRAPH, currPlotHandle, ATTR_PLOT_LG_TEXT, "Q Signal");

	
    /* Generate and Display Window Data */       
    LinEv1D (window, NUMPOINTS, 0, 1, window);
    ScaledWindow (window, NUMPOINTS, windowing, &constants);
    PlotY (panelHandle, PANEL_WINDOWGRAPH, window, NUMPOINTS,
           VAL_DOUBLE, VAL_THIN_LINE, VAL_NO_POINT, VAL_SOLID, 1, VAL_RED);
              
    
    /* Apply Window to Complex Signal */
    CxScaledWindow (tempArray, NUMPOINTS, windowing, -1, &constants);
  
	
	/* Extract I/Q Signals and Display the Power Spectrum */
    for (i=0;i<NUMPOINTS;i++) {
		waveTime[0][i] = tempArray[i].real;
		waveTime[1][i] = tempArray[i].imaginary;
	}
	
	for (i=0;i<2;i++) {
		AutoPowerSpectrum (waveTime[i], NUMPOINTS, 1/1000.0, spectrum, &freqSpace);
	    switch (scaling) {
	        case 1:
	            for (j=0; j<(NUMPOINTS/2); j++) 
	                spectrum[j] = 20*(log10(spectrum[j]));
	            break;
	    }
	    PlotY (panelHandle, PANEL_FREQGRAPH, spectrum, NUMPOINTS/2,
	          VAL_DOUBLE, VAL_THIN_LINE, VAL_NO_POINT, VAL_SOLID, 1, (i)?VAL_BLUE:VAL_RED);
	}
}


/****************************************************************/
/*                                                              */
/*  Quit Function                                               */
/*                                                              */
/*  The Quit function is called whenever the  user clicks on    */
/*  the Quit button. The execution of the program is            */
/*  terminated.                                                 */
/*                                                              */
/****************************************************************/
int CVICALLBACK Quit (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            QuitUserInterface (0);

            break;
    }
    return 0;
}

/*****************************************************************/
/*                                                               */
/* Help Button Callback                                          */
/*                                                               */
/*****************************************************************/
int CVICALLBACK HelpCallback (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_RIGHT_CLICK:
        case EVENT_COMMIT:
            MessagePopup ("Complex Signal Windowing Example Program",HELP_MSG);
        break;
    }
    return 0;
}


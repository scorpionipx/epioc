/*****************************************************************/
/*                                                               */
/*  Phase Difference Measurement Program                         */
/*                                                               */
/*****************************************************************/
#define HELP_MSG \
"This program is a simple example of the calculation of the \n\
phase difference between two sine waves.  The user selects \n\
the number of points and cycles, and the phase and amplitude \n\
of two sine waves.  When the user clicks on the Generate \n\
button, the program plots the two waves and determines where \n\
the peak values of the waves are.  The value and index where \n\
this peak occurs are displayed in the appropriate controls. \n\
The graph cursors are set to these points.  The difference in \n\
phase is then calculated and displayed in the appropriate \n\
control using the formula: \n\n\
  phasediff = (cycles/numpoints) * 360 * (peak index diff) \n\n\
The sum and correlation of the two waves are plotted in the \n\
lower graphs to display the effects of phase shifting."
                                                             
#include <cvirte.h>     /* needed if linking executable in external compiler; harmless otherwise */
#include <ansi_c.h>
#include <analysis.h>
#include <userint.h>
#include "phasedif.h"

void GenerateGraphs(void);

static int plot1;
static int plot2;
static int mainpnl;
static int numpoints = 256;
static double cycles = 3.0;
static double sig1amp = 9.0;
static double sig2amp = 5.0;
static double sig1phase = 10.0;
static double sig2phase = 60.0;
static double wave1[2048];
static double wave2[2048];
static double sumwave[2048];
static double corrwave[(2048*2)-1];
static int i;
static double wave1maxval = 0.0;
static int wave1maxind = 0;
static double wave2maxval = 0.0;
static int wave2maxind = 0;
static double phasediff;
static int autoGenerateGraphs = 1;

int main (int argc, char *argv[])
{
    if (InitCVIRTE (0, argv, 0) == 0)    /* Needed if linking in external compiler; harmless otherwise */
        return -1;    /* out of memory */
    
    if ((mainpnl = LoadPanel (0, "phasedif.uir", MAINPNL)) < 0)
        return -1;
    if (autoGenerateGraphs) GenerateGraphs();
    DisplayPanel (mainpnl);
    RunUserInterface ();
	DiscardPanel (mainpnl);
    return 0;
}

int CVICALLBACK Getnumpoints (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            GetCtrlVal (mainpnl, MAINPNL_NUMPOINTS, &numpoints);
            SetCtrlAttribute (mainpnl, MAINPNL_CYCLES, ATTR_MAX_VALUE,
                              (double)(numpoints-1));
            if (autoGenerateGraphs) GenerateGraphs();

            break;
        case EVENT_RIGHT_CLICK:
            MessagePopup ("Set Number of Points",
                          "Sets the number of points in each wave.  More points results in greater accuracy in the phase difference calculation.");

            break;
    }
    return 0;
}

int CVICALLBACK Getcycles (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            GetCtrlVal (mainpnl, MAINPNL_CYCLES, &cycles);
            if (autoGenerateGraphs) GenerateGraphs();

            break;
        case EVENT_RIGHT_CLICK:
            MessagePopup ("Set Cycles", "Sets the number of cycles in each wave.");

            break;
    }
    return 0;
}

int CVICALLBACK Getsig1amp (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            GetCtrlVal (mainpnl, MAINPNL_SIG1AMP, &sig1amp);
            if (autoGenerateGraphs) GenerateGraphs();

            break;
        case EVENT_RIGHT_CLICK:
            MessagePopup ("Set Signal 1 Amplitude",
                          "Sets the amplitude of the first signal.");

            break;
    }
    return 0;
}

int CVICALLBACK Getsig2amp (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            GetCtrlVal (mainpnl, MAINPNL_SIG2AMP, &sig2amp);
            if (autoGenerateGraphs) GenerateGraphs();

            break;
        case EVENT_RIGHT_CLICK:
            MessagePopup ("Set Signal 2 Amplitude",
                          "Sets the amplitude of the second signal.");

            break;
    }
    return 0;
}

int CVICALLBACK Getsig1phase (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            GetCtrlVal (mainpnl, MAINPNL_SIG1PHASE, &sig1phase);
            if (autoGenerateGraphs) GenerateGraphs();

            break;
        case EVENT_RIGHT_CLICK:
            MessagePopup ("Set Signal 1 Phase",
                          "Sets the phase of the first signal.");

            break;
    }
    return 0;
}

int CVICALLBACK Getsig2phase (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            GetCtrlVal (mainpnl, MAINPNL_SIG2PHASE, &sig2phase);
            if (autoGenerateGraphs) GenerateGraphs();

            break;
        case EVENT_RIGHT_CLICK:
            MessagePopup ("Set Signal 2 Phase",
                          "Sets the phase of the second signal.");

            break;
    }
    return 0;
}

int CVICALLBACK Generate (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            GenerateGraphs();

            break;
        case EVENT_RIGHT_CLICK:
            MessagePopup ("Generate",
                          "Generates the wave plots and phase difference calculation.");

            break;
    }
    return 0;
}

void GenerateGraphs(void)
{
    double *peakLoc, *peakAmp, *peakDeriv;
    ssize_t count;
    
    /* Generate signals */
    SinePattern (numpoints, sig1amp, sig1phase, cycles, wave1);
    SinePattern (numpoints, sig2amp, sig2phase, cycles, wave2);
    for (i=0; i<numpoints; i++) {
        sumwave[i] = wave1[i] + wave2[i];
    }
    
    /* Calculate correlation */
    Correlate (wave1, numpoints, wave2, numpoints, corrwave);
    
    /* Calculate Peak and phase difference */
    PeakDetector (wave1, numpoints, 0.0, 3, 0, 1, 1, &count, &peakLoc, &peakAmp, &peakDeriv);
    if (count>0) 
    {
        wave1maxind = peakLoc[0];
        wave1maxval = peakAmp[0];
    }    
    if (peakLoc) 
        FreeAnalysisMem (peakLoc);
    if (peakAmp) 
        FreeAnalysisMem (peakAmp);
    if (peakDeriv) 
        FreeAnalysisMem (peakDeriv);
    
    PeakDetector (wave2, numpoints, 0.0, 3, 0, 1, 1, &count, &peakLoc, &peakAmp, &peakDeriv);
    if (count>0) 
    {
        wave2maxind = peakLoc[0];
        wave2maxval = peakAmp[0];
    }    
    if (peakLoc) 
        FreeAnalysisMem (peakLoc);
    if (peakAmp) 
        FreeAnalysisMem (peakAmp);
    if (peakDeriv) 
        FreeAnalysisMem (peakDeriv);
    
    phasediff = (cycles/numpoints) * (wave1maxind - wave2maxind) * 360.0;
    phasediff = fmod (phasediff, 360.0);
    
    /* Update UIR */
    DeleteGraphPlot (mainpnl, MAINPNL_SIGGRAPH, -1, VAL_DELAYED_DRAW);
    DeleteGraphPlot (mainpnl, MAINPNL_CORRGRAPH, -1, VAL_DELAYED_DRAW);
    DeleteGraphPlot (mainpnl, MAINPNL_SUMGRAPH, -1, VAL_DELAYED_DRAW);
    plot1 = PlotY (mainpnl, MAINPNL_SIGGRAPH, wave1, numpoints,
                   VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID,
                   1, VAL_RED);
    plot2 = PlotY (mainpnl, MAINPNL_SIGGRAPH, wave2, numpoints,
                   VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID,
                   1, VAL_DK_BLUE);
    PlotY (mainpnl, MAINPNL_SUMGRAPH, sumwave, numpoints, VAL_DOUBLE,
           VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, 1, VAL_RED);
    PlotY (mainpnl, MAINPNL_CORRGRAPH, corrwave, ((2*numpoints)-1),
           VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, 1,
           VAL_RED);
    SetCtrlVal (mainpnl, MAINPNL_SIG1MAX, wave1maxval);
    SetCtrlVal (mainpnl, MAINPNL_SIG2MAX, wave2maxval);
    SetCtrlVal (mainpnl, MAINPNL_SIG1IND, wave1maxind);
    SetCtrlVal (mainpnl, MAINPNL_SIG2IND, wave2maxind);
    SetGraphCursorIndex (mainpnl, MAINPNL_SIGGRAPH, 1, plot1, wave1maxind);
    SetGraphCursorIndex (mainpnl, MAINPNL_SIGGRAPH, 2, plot2, wave2maxind);
    SetCtrlVal (mainpnl, MAINPNL_PHASEDIFF, phasediff);
    
}

int CVICALLBACK Quit (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            QuitUserInterface (0);
            break;
        case EVENT_RIGHT_CLICK:
            MessagePopup ("Quit Program", "Quits the program.");

            break;
    }
    return 0;
}


int CVICALLBACK SetAutoGenerate (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_VAL_CHANGED:
            GetCtrlVal(panel, control ,&autoGenerateGraphs);

            break;
    }
    return 0;
}

/*****************************************************************/
/*                                                               */
/* Help Button Callback                                          */
/*                                                               */
/*****************************************************************/
int CVICALLBACK HelpCallback (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_RIGHT_CLICK:
        case EVENT_COMMIT:
            MessagePopup ("Phase Difference Measurement Program",HELP_MSG);
        break;
    }
    return 0;
}

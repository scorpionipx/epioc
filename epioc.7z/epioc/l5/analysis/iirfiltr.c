/*----------------------------------------------------------------------------*/
/* Infinite Impulse Response (IIR) Filter                                     */
/*----------------------------------------------------------------------------*/
#define HELP_MSG \
"This example illustrates the design of an Infinite Impulse Response (IIR)\n\
Filter. In this example, we use the Cascade Coefficient technique for\n\
designing filters rather than the simple one step method.  This method is\n\
more stable than the traditional one step method.  We recommend that you use\n\
this method for designing IIR filters."

/*----------------------------------------------------------------------------*/
/* Include                                                                    */
/*----------------------------------------------------------------------------*/
#include <ansi_c.h>
#include <cvirte.h>     /* Needed if linking in external compiler; harmless otherwise */
#include <userint.h>
#include "iirfiltr.h"
#include <analysis.h>

/*----------------------------------------------------------------------------*/
/* Variables                                                                  */
/*----------------------------------------------------------------------------*/
static int panelHandle;
static int autoRun = 1;

/*----------------------------------------------------------------------------*/
/* Prototypes                                                                 */
/*----------------------------------------------------------------------------*/
int DoIIRFilter(void);

/*----------------------------------------------------------------------------*/
/* Main                                                                       */
/*----------------------------------------------------------------------------*/
int main (int argc, char *argv[])
{
    if (InitCVIRTE (0, argv, 0) == 0)   /* Needed if linking in external compiler; harmless otherwise */
        return -1;  /* out of memory */
    if ((panelHandle = LoadPanel (0, "iirfiltr.uir", PANEL)) < 0)
        return -1;
        
    DoIIRFilter();
        
    DisplayPanel (panelHandle);
    RunUserInterface ();
	DiscardPanel (panelHandle);
    return 0;
}

/*----------------------------------------------------------------------------*/
/* DoIIRFilter                                                                */
/*----------------------------------------------------------------------------*/
int DoIIRFilter(void)
{
    static int filter_design;
    static int filter_type;
    static double ripple;
    static double attentuation;
    static int filter_order;
    static int display_type;
    static double sampling_rate;
    static double upper_cutoff_frequency;
    static double lower_cutoff_frequency;
    static IIRFilterPtr filter_information;
    static int i;
    static int err;
    double *input_signal;
    double *filtered_signal;
    double *filtered_signal_im;
    double *x_array;
    double *y_array;
    
    GetCtrlVal(panelHandle, PANEL_Design, &filter_design);
    GetCtrlVal(panelHandle, PANEL_Type, &filter_type);
    GetCtrlVal(panelHandle, PANEL_Ripple, &ripple);
    GetCtrlVal(panelHandle, PANEL_Attentuation, &attentuation);
    GetCtrlVal(panelHandle, PANEL_Order, &filter_order);
    GetCtrlVal(panelHandle, PANEL_SamplingRate, &sampling_rate);
    GetCtrlVal(panelHandle, PANEL_HCF, &upper_cutoff_frequency);
    GetCtrlVal(panelHandle, PANEL_LCF, &lower_cutoff_frequency);
    GetCtrlVal(panelHandle, PANEL_Display, &display_type);
    
    switch(filter_type)
    {
        case 0 : /* LowPass Filter */
        filter_information = AllocIIRFilterPtr (LOWPASS, filter_order);
        break;
            
        case 1: /* HighPass Filter */
        filter_information = AllocIIRFilterPtr (HIGHPASS, filter_order);    
        break;
            
        case 2: /* BandPass Filter */
        filter_information = AllocIIRFilterPtr (BANDPASS, filter_order);    
        break;
            
        case 3: /* BandStop Filter */
        filter_information = AllocIIRFilterPtr (BANDSTOP, filter_order);    
        break;
    }
    
    switch(filter_design)
    {
        case 0 : /* Butterworth Filter */
        err = Bw_CascadeCoef (sampling_rate, lower_cutoff_frequency,
                              upper_cutoff_frequency, filter_information);
        break;
        
        case 1: /* Chebyshev Filter */
        err = Ch_CascadeCoef (sampling_rate, lower_cutoff_frequency,
                              upper_cutoff_frequency, ripple,
                              filter_information);
        break;
        
        case 2: /* Inverse Chebyshev Filters */
        err = InvCh_CascadeCoef (sampling_rate, lower_cutoff_frequency,
                                 upper_cutoff_frequency, attentuation,
                                 filter_information);
        break;
        
        case 3: /* Elliptic Filter */
        err = Elp_CascadeCoef (sampling_rate, lower_cutoff_frequency,
                               upper_cutoff_frequency, ripple, attentuation,
                               filter_information);
        break;
        
        case 4: /* Bessel Filter */
        err = Bessel_CascadeCoef (sampling_rate, lower_cutoff_frequency,
                                  upper_cutoff_frequency, filter_information);
        break;
    }
    input_signal = (double *)malloc(1024*sizeof(double));
    if(input_signal == NULL)
    {
		FreeIIRFilterPtr(filter_information);
        return OutOfMemAnlysErr;
    }
    err = Impulse (1024, 1.0, 0, input_signal);
    if(err != NoAnlysErr)
    {
		FreeIIRFilterPtr(filter_information);
        free(input_signal);
        return err;
    }
    filtered_signal = (double *)malloc(1024*sizeof(double));
    if(filtered_signal == NULL)
    {
		FreeIIRFilterPtr(filter_information);
        free(input_signal);
        return OutOfMemAnlysErr;
    }
    
    filtered_signal_im = (double *)malloc(1024*sizeof(double));
    if(filtered_signal_im == NULL)
    {
		FreeIIRFilterPtr(filter_information);
        free(input_signal);
        free(filtered_signal);
        return OutOfMemAnlysErr;
    }
    err = IIRCascadeFiltering (input_signal, 1024, filter_information,
                               filtered_signal);
	FreeIIRFilterPtr(filter_information);
	
    if(err != NoAnlysErr)
    {
        free(input_signal);
        free(filtered_signal);
        free(filtered_signal_im);
    }
    /* ReFFT function returns the real part of the FFT in the input array filtered_signal */
    /* and the imaginary part of the FFT in the array filtered_signal_im */

    err = ReFFT (filtered_signal, filtered_signal_im, 1024);
    if(err != NoAnlysErr)
    {   
        free(input_signal);
        free(filtered_signal);
        free(filtered_signal_im);
    }
    
    x_array = (double *)malloc(512*sizeof(double));
    if(x_array == NULL)
    {
        free(input_signal);
        free(filtered_signal);
        free(filtered_signal_im);
        return OutOfMemAnlysErr;
    }
    
    y_array = (double *)malloc(512*sizeof(double));
    if(x_array == NULL)
    {
        free(input_signal);
        free(filtered_signal);
        free(filtered_signal_im);
        free(x_array);
        return OutOfMemAnlysErr;
    }
    
    for(i = 0; i < 512; i++) *(x_array+i) = i * (sampling_rate/1024.0);
    if(display_type == 1)
    {
        for(i = 0; i < 512; i++) *(y_array+i) = 
            20.0*log10(sqrt((*(filtered_signal+i)**(filtered_signal+i))+(*(filtered_signal_im+i)**(filtered_signal_im+i))));
    }
    else
    {
        for(i = 0; i < 512; i++) *(y_array+i) = 
                                                                                                               
            sqrt((*(filtered_signal+i)**(filtered_signal+i))+(*(filtered_signal_im+i)**(filtered_signal_im+i)));
    }
    DeleteGraphPlot (panelHandle, PANEL_GRAPH1, -1, VAL_DELAYED_DRAW);
    PlotXY (panelHandle, PANEL_GRAPH1, x_array, y_array, 512,
            VAL_DOUBLE, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE,
            VAL_SOLID, 1, VAL_RED);
    
    for(i = 0; i < 512; i++) *(filtered_signal_im+i) = atan2(*(filtered_signal_im+i),*(filtered_signal+i));
    err = UnWrap1D (filtered_signal_im, 512);
    if(err != NoAnlysErr)
    {
        free(input_signal);
        free(filtered_signal);
        free(filtered_signal_im);
        free(x_array);
        free(y_array);
    }
    DeleteGraphPlot (panelHandle, PANEL_GRAPH2, -1, VAL_DELAYED_DRAW);
    PlotXY (panelHandle, PANEL_GRAPH2, x_array, filtered_signal_im, 512,
            VAL_DOUBLE, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE,
            VAL_SOLID, 1, VAL_RED);
    free(input_signal);
    free(filtered_signal);
    free(filtered_signal_im);
    free(x_array);
    free(y_array);

    return 0;

}   

/*----------------------------------------------------------------------------*/
/* RunProgram                                                                 */
/*----------------------------------------------------------------------------*/
int CVICALLBACK RunProgram (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            if ((autoRun) || (control == PANEL_RUN))
                DoIIRFilter();
            
            break;
    }
    return 0;
}

/*----------------------------------------------------------------------------*/
/* QuitProgram                                                                */
/*----------------------------------------------------------------------------*/
int CVICALLBACK QuitProgram (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            QuitUserInterface (0);
            break;
    }
    return 0;
}

/*----------------------------------------------------------------------------*/
/* Help                                                                       */
/*----------------------------------------------------------------------------*/
int CVICALLBACK Help (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_RIGHT_CLICK:
        case EVENT_COMMIT:
            MessagePopup ("Infinite Impulse Response (IIR) Filter", HELP_MSG);
        break;
    }
    return 0;
}


int CVICALLBACK AutoChange (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event)
        {
        case EVENT_COMMIT:
            GetCtrlVal(panel, control, &autoRun);
            break;
        }
    return 0;
}

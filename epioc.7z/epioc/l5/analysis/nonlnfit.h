/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  MAINPNL                         1
#define  MAINPNL_GRAPH                   2
#define  MAINPNL_NUMPOINTS               3       /* callback function: Getnumpoints */
#define  MAINPNL_FUNCTFIT                4       /* callback function: Getfunctfit */
#define  MAINPNL_FUNCTTEMPLATE           5       /* callback function: Getfuncttemplate */
#define  MAINPNL_NOISELEVEL              6       /* callback function: Getnoiselevel */
#define  MAINPNL_FITTEMPTEXT             7
#define  MAINPNL_DATATEMPTEXT            8
#define  MAINPNL_FITPAR2                 9
#define  MAINPNL_FITPAR1                 10
#define  MAINPNL_IDEALPAR2               11      /* callback function: Getidealpar2 */
#define  MAINPNL_IDEALPAR1               12      /* callback function: Getidealpar1 */
#define  MAINPNL_HELP                    13      /* callback function: HelpCallback */
#define  MAINPNL_FITCURVE                14      /* callback function: FitCurve */
#define  MAINPNL_QUIT                    15      /* callback function: Quit */
#define  MAINPNL_ERROR                   16
#define  MAINPNL_AUTOFIT                 17      /* callback function: SetAutoFitState */
#define  MAINPNL_DECORATION              18
#define  MAINPNL_DECORATION_2            19
#define  MAINPNL_DECORATION_3            20


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */ 

int  CVICALLBACK FitCurve(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getfunctfit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getfuncttemplate(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getidealpar1(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getidealpar2(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getnoiselevel(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getnumpoints(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK HelpCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Quit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SetAutoFitState(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif

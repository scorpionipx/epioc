/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                           1
#define  PANEL_SAMPLES                   2       /* callback function: RunProgram */
#define  PANEL_ORDER                     3       /* callback function: RunProgram */
#define  PANEL_MSE                       4
#define  PANEL_GRAPH                     5
#define  PANEL_RUN                       6       /* callback function: RunProgram */
#define  PANEL_HELP                      7       /* callback function: Help */
#define  PANEL_QUIT                      8       /* callback function: Quit */
#define  PANEL_SHIFT                     9       /* callback function: RunProgram */
#define  PANEL_COEFS1                    10
#define  PANEL_COEFS2                    11
#define  PANEL_COEFS3                    12
#define  PANEL_AUTO                      13      /* callback function: AutoChange */
#define  PANEL_TEXTMSG                   14


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */ 

int  CVICALLBACK AutoChange(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Help(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Quit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK RunProgram(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif

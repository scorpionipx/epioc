/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  MAINPNL                         1
#define  MAINPNL_CORRGRAPH               2
#define  MAINPNL_SIG2GRAPH               3
#define  MAINPNL_SIG1GRAPH               4
#define  MAINPNL_SIG2WAVETYPE            5       /* callback function: Getsig2wavetype */
#define  MAINPNL_SIG1WAVETYPE            6       /* callback function: Getsig1wavetype */
#define  MAINPNL_SIG2NOISE               7       /* callback function: Getsig2noise */
#define  MAINPNL_SIG1NOISE               8       /* callback function: Getsig1noise */
#define  MAINPNL_HELP                    9       /* callback function: HelpCallback */
#define  MAINPNL_GENERATESIG1            10      /* callback function: Generatesig1 */
#define  MAINPNL_SIG2CYCLES              11      /* callback function: Getsig2cycles */
#define  MAINPNL_SIG1CYCLES              12      /* callback function: Getsig1cycles */
#define  MAINPNL_SIG2PHASE               13      /* callback function: Getsig2phase */
#define  MAINPNL_SIG1PHASE               14      /* callback function: Getsig1phase */
#define  MAINPNL_SIG2POINTS              15      /* callback function: Getsig2points */
#define  MAINPNL_SIG1POINTS              16      /* callback function: Getsig1points */
#define  MAINPNL_QUIT                    17      /* callback function: Quit */
#define  MAINPNL_SIG2NOISEAMP            18      /* callback function: Getsig2noiseamp */
#define  MAINPNL_SIG1NOISEAMP            19      /* callback function: Getsig1noiseamp */
#define  MAINPNL_CHECKBOX                20      /* callback function: SetAutoGenerate */
#define  MAINPNL_DECORATION              21
#define  MAINPNL_DECORATION_2            22
#define  MAINPNL_TEXTMSG1                23
#define  MAINPNL_TEXTMSG2                24


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */ 

int  CVICALLBACK Generatesig1(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig1cycles(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig1noise(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig1noiseamp(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig1phase(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig1points(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig1wavetype(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig2cycles(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig2noise(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig2noiseamp(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig2phase(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig2points(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig2wavetype(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK HelpCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Quit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SetAutoGenerate(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif

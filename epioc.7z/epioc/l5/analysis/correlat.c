/*****************************************************************/
/*                                                               */
/*  Correlation Function Example Program                         */
/*  National Instruments                                         */
/*  August, 1995                                                 */
/*                                                               */
/*****************************************************************/
#define HELP_MSG \
"This program serves as an example use of the Correlation \n\
function in the Advanced Analysis library.  There are two \n\
sets of controls that specify parameters for two signals \n\
displayed on the upper two graphs.  The user can specify the \n\
number of points, cycles, wave type, and amount of noise of \n\
each of the two signals.  When the user specifies these \n\
parameters and clicks on the Generate button, the program \n\
displays the two signals on the upper two graphs and the \n\
correlation of the signals on the lower graph.  The user \n\
can simulate the detection of a signature signal in a longer \n\
'acquired' signal with noise present.  Peaks in the \n\
correlation function represent the presence of the signature \n\
signal in the acquired signal. "

#include <cvirte.h>     /* needed if linking executable in external compiler; harmless otherwise */
#include <analysis.h>
#include <userint.h>
#include "correlat.h"

/*****************************************************************/
/*                                                               */
/*  Variable Descriptions                                        */
/*                                                               */
/*  1.  mainpnl - handle for the main panel in the user          */
/*                interface                                      */
/*  2.  sig1wavetype - variable indicating which type of wave    */
/*                     has been selected by the user             */
/*                     0 = sine wave (default)                   */
/*                     1 = square wave                           */
/*                     2 = triangle wave                         */
/*  3.  sig1points - contains the number of points in the first  */
/*                   signal (default = 128)                      */
/*  4.  sig1phase - contains the phase offset of the first       */
/*                  signal (default = 0)                         */
/*  5.  wave1 - array containing the points of wave 1            */
/*  6.  sig1noise - indicates whether noise is added to the      */
/*                  first signal prior to graphing and           */
/*                  calculating the correlation                  */
/*                  0 = disabled (default)                       */
/*                  1 = enabled                                  */
/*  7.  sig1cycles - number of cycles in the first signal        */
/*                   (default = 5)                               */
/*  8.  noisewave1 - array containing the noise that is added to */
/*                   the first signal                            */
/*  9.  i - loop variable                                        */
/* 10.  sig1noiseamp - standard deviation of the Gaussian noise  */
/*                     added to the first signal                 */
/* 11.  seed - seed passed to the Gaussian noise function        */
/*             (begins at 1 and changes throughout the program)  */
/* 12.  sig2wavetype - signal type for the second wave           */
/*                     0 = sine wave (default)                   */
/*                     1 = square wave                           */
/*                     2 = triangular wave                       */
/* 13.  sig2points - number of points in the second wave         */
/*                   (default = 32)                              */
/* 14.  sig2phase - phase of the second signal (default = 0)     */
/* 15.  wave2 - array containing the points of the second wave   */
/* 16.  sig2noise - indicates whether noise will be added to the */
/*                  second signal                                */
/*                  0 = disabled (default)                       */
/*                  1 = enabled                                  */
/* 17.  sig2cycles - number of cycles in the second signal       */
/*                   (default = 1)                               */
/* 18.  noisewave2 - array containing the Gaussian noise added   */
/*                   to the second signal                        */
/* 19.  sig2noiseamp - standard deviation of the Gaussian noise  */
/*                     added to the second signal                */
/* 20.  wavecorr - array containing the correlation of the two   */
/*                 signals                                       */
/*                                                               */
/*****************************************************************/

void GenerateGraphs(void);

static int mainpnl;
static int sig1wavetype = 0;
static int sig1points = 128;
static double sig1phase = 0.0;
static double wave1[2048];
static int sig1noise = 0;
static double sig1cycles = 5.0;
static double noisewave1[2048];
static int i;
static double sig1noiseamp = 1.0;
static int seed = 1;
static int sig2wavetype = 0;
static int sig2points = 32;
static double sig2phase = 0.0;
static double wave2[2048];
static int sig2noise = 0;
static double sig2cycles = 1.0;
static double noisewave2[2048];
static double sig2noiseamp = 1.0;
static double wavecorr[(2048*2)-1];
static int autoGenerateGraphs = 1;

/*****************************************************************/
/*                                                               */
/*  Main Function Description                                    */
/*                                                               */
/*  The main function loads and displays the main panel.         */
/*                                                               */
/*****************************************************************/

int main (int argc, char *argv[])
{
    if (InitCVIRTE (0, argv, 0) == 0)    /* Needed if linking in external compiler; harmless otherwise */
        return -1;    /* out of memory */
    
    if ((mainpnl = LoadPanel (0, "correlat.uir", MAINPNL)) < 0)
        return -1;
        
    if (autoGenerateGraphs) GenerateGraphs();
    DisplayPanel (mainpnl);
    RunUserInterface ();
    DiscardPanel (mainpnl);
    return 0;
}

/*****************************************************************/
/*                                                               */
/*  Generatesig1 Function Description                            */
/*                                                               */
/*  The Generatesig1 function is called when the user clicks on  */
/*  the Generate button.  This will call GenerateGraphs          */
/*                                                               */
/*****************************************************************/

int CVICALLBACK Generatesig1 (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            GenerateGraphs();
            break;
        case EVENT_RIGHT_CLICK:
            MessagePopup ("Generate Waveforms",
                          "Generates the two signals and their correlation.");

            break;
    }
    return 0;
}


/*****************************************************************/
/*  This function determines which type of waves                 */
/*  waves have been selected and generates each signal according */
/*  to the selected parameters.  If noise has been enabled for   */
/*  either or both signals, the function then adds Gaussian      */
/*  noise to the appropriate signal(s).  The function then plots */
/*  the two signals on the upper two graphs.  The correlation is */
/*  then calculated and plotted on the lower graph.              */
/*****************************************************************/
void GenerateGraphs(void)
{
    switch (sig1wavetype) {
        case 0:
            SinePattern (sig1points, 5.0, sig1phase, sig1cycles, wave1);
            break;
        case 1:
            SquareWave (sig1points, 5.0, (sig1cycles/sig1points), &sig1phase,
                        50.0, wave1);
            break;
        case 2:
            TriangleWave (sig1points, 5.0, (sig1cycles/sig1points), &sig1phase,
                          wave1);
            break;
    }
    
    if (sig1noise == 1) {
        GaussNoise (sig1points, sig1noiseamp, seed, noisewave1);
        for (i=0; i<sig1points; i++) {
            wave1[i] = wave1[i] + noisewave1[i];
        }
    }
    
    DeleteGraphPlot (mainpnl, MAINPNL_SIG1GRAPH, -1, VAL_IMMEDIATE_DRAW);
    PlotY (mainpnl, MAINPNL_SIG1GRAPH, wave1, sig1points, VAL_DOUBLE,
           VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, 1, VAL_RED);
            
    switch (sig2wavetype) {
        case 0:
            SinePattern (sig2points, 5.0, sig2phase, sig2cycles, wave2);
            break;
        case 1:
            SquareWave (sig2points, 5.0, (sig2cycles/sig2points), &sig2phase,
                        50.0, wave2);
            break;
        case 2:
            TriangleWave (sig2points, 5.0, (sig2cycles/sig2points), &sig2phase,
                          wave2);
            break;
    }
    
    if (sig2noise == 1) {
        GaussNoise (sig2points, sig2noiseamp, seed, noisewave2);
        for (i=0; i<sig2points; i++) {
            wave2[i] = wave2[i] + noisewave2[i];
        }
    }
    
    DeleteGraphPlot (mainpnl, MAINPNL_SIG2GRAPH, -1, VAL_IMMEDIATE_DRAW);
    PlotY (mainpnl, MAINPNL_SIG2GRAPH, wave2, sig2points, VAL_DOUBLE,
           VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, 1, VAL_RED);
           
    if ((sig1noise == 1) || (sig2noise == 1)) {
       seed = seed + 1;
       if (seed > 50) {
          seed = 1;
       }
    }
    Correlate (wave1, sig1points, wave2, sig2points, wavecorr);
    DeleteGraphPlot (mainpnl, MAINPNL_CORRGRAPH, -1, VAL_IMMEDIATE_DRAW);
    PlotY (mainpnl, MAINPNL_CORRGRAPH, wavecorr,
           (sig1points + sig2points -1), VAL_DOUBLE, VAL_THIN_LINE,
           VAL_EMPTY_SQUARE, VAL_SOLID, 1, VAL_RED);
}           
            

/*****************************************************************/
/*                                                               */
/*  Getsig1wavetype Function Description                         */
/*                                                               */
/*  The Getsig1wavetype function is called whenever the user     */
/*  changes the signal type for the first signal.  The function  */
/*  gets the new value of the control and stores it in the       */
/*  sig1wavetype variable.                                       */
/*                                                               */
/*****************************************************************/

int CVICALLBACK Getsig1wavetype (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            GetCtrlVal (mainpnl, MAINPNL_SIG1WAVETYPE, &sig1wavetype);
            if (autoGenerateGraphs) GenerateGraphs();

            break;
        case EVENT_RIGHT_CLICK:
            MessagePopup ("Set Signal 1 Wave Type",
                          "Selects the type of wave for the first signal - sine, square, or triangular.");

            break;
    }
    return 0;
}

/*****************************************************************/
/*                                                               */
/*  Getsig1noise Function Description                            */
/*                                                               */
/*  The Getsig1noise function is called whenever the user        */
/*  changes the value of the noise enable switch for the first   */
/*  signal.  The function gets the new value of the control and  */
/*  puts it in the sig1noise variable.  If the user has disabled */
/*  the noise, the function then disables the noise amplitude    */
/*  control for the first signal.  If the user enables noise,    */
/*  the function enables the noise amplitude control for the     */
/*  first signal.                                                */
/*                                                               */
/*****************************************************************/

int CVICALLBACK Getsig1noise (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            GetCtrlVal (mainpnl, MAINPNL_SIG1NOISE, &sig1noise);
            if (sig1noise == 0) {
                SetInputMode (mainpnl, MAINPNL_SIG1NOISEAMP, 0);
                
            }
            else {
                SetInputMode (mainpnl, MAINPNL_SIG1NOISEAMP, 1);
                
            }
            
            if (autoGenerateGraphs) GenerateGraphs();
              
            break;
        case EVENT_RIGHT_CLICK:
            MessagePopup ("Set Signal 1 Noise",
                          "Enables or disables noise addition to the first signal.");

            break;
    }
    return 0;
}

/*****************************************************************/
/*                                                               */
/*  Getsig1cycles Function Description                           */
/*                                                               */
/*  The Getsig1cycles function is called whenever the user       */
/*  changes the value of the control for the number of cycles in */
/*  the first signal.  The function gets the new value of the    */
/*  control and puts it in the sig1cycles variable.              */
/*                                                               */
/*****************************************************************/

int CVICALLBACK Getsig1cycles (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            GetCtrlVal (mainpnl, MAINPNL_SIG1CYCLES, &sig1cycles);
            if (autoGenerateGraphs) GenerateGraphs();

            break;
        case EVENT_RIGHT_CLICK:
            MessagePopup ("Select Signal 1 Cycles",
                          "Selects the number of cycles in the first signal.");

            break;
    }
    return 0;
}

/*****************************************************************/
/*                                                               */
/*  Getsig1phase Function Description                            */
/*                                                               */
/*  The Getsig1phase function is called whenever the user        */
/*  changes the vaule of the phase of the first signal.  The     */
/*  function gets the new value of the control and puts it in    */
/*  the sig1phase variable.                                      */
/*                                                               */
/*****************************************************************/

int CVICALLBACK Getsig1phase (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            GetCtrlVal (mainpnl, MAINPNL_SIG1PHASE, &sig1phase);
            if (autoGenerateGraphs) GenerateGraphs();

            break;
        case EVENT_RIGHT_CLICK:
            MessagePopup ("Select Signal 1 Phase",
                          "Selects the phase offset for the first signal.");

            break;
    }
    return 0;
}

/*****************************************************************/
/*                                                               */
/*  Getsig1points Function Description                           */
/*                                                               */
/*  The Getsig1points function is called whenever the user       */
/*  changes the number of points in the first signal.  The       */
/*  function gets the new value of the control and puts it in    */
/*  the sig1points variable.                                     */
/*                                                               */
/*****************************************************************/

int CVICALLBACK Getsig1points (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            GetCtrlVal (mainpnl, MAINPNL_SIG1POINTS, &sig1points);
            if (autoGenerateGraphs) GenerateGraphs();

            break;
        case EVENT_RIGHT_CLICK:
            MessagePopup ("Set Signal 1 Points",
                          "Selects the number of points in the first signal.");

            break;
    }
    return 0;
}

/*****************************************************************/
/*                                                               */
/*  Quit Function Description                                    */
/*                                                               */
/*  The Quit function is called when the user clicks on the Quit */
/*  button on the main panel.  The function quits the program.   */
/*                                                               */
/*****************************************************************/

int CVICALLBACK Quit (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            QuitUserInterface (0);
            break;
        case EVENT_RIGHT_CLICK:
            MessagePopup ("Quit Program", "Quits the program.");

            break;
    }
    return 0;
}

/*****************************************************************/
/*                                                               */
/*  Getsig1noiseamp Function Description                         */
/*                                                               */
/*  The Getsig1noiseamp function is called whenever the user     */
/*  changes the value of the control for the noise amplitude for */
/*  the first signal.  The function gets the new value of the    */
/*  control and puts it in the sig1noiseamp variable.            */
/*                                                               */
/*****************************************************************/

int CVICALLBACK Getsig1noiseamp (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            GetCtrlVal (mainpnl, MAINPNL_SIG1NOISEAMP, &sig1noiseamp);
            if (autoGenerateGraphs) GenerateGraphs();

            break;
        case EVENT_RIGHT_CLICK:
            MessagePopup ("Select Signal 1 Noise Amplitude",
                          "Sets the standard deviation of the Gaussian noise added to the first signal.");

            break;
    }
    return 0;
}

/*****************************************************************/
/*                                                               */
/*  Getsig2points Function Description                           */
/*                                                               */
/*  The Getsig2points function is called whenever the user       */
/*  changes the value of the control for the number of points    */
/*  in the second signal.  The function gets the new value of    */
/*  the control and puts it in the sig2points variable.          */
/*                                                               */
/*****************************************************************/

int CVICALLBACK Getsig2points (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            GetCtrlVal (mainpnl, MAINPNL_SIG2POINTS, &sig2points);
            if (autoGenerateGraphs) GenerateGraphs();

            break;
        case EVENT_RIGHT_CLICK:
            MessagePopup ("Select Signal 2 Points",
                          "Selects the number of points in the second signal.");

            break;
    }
    return 0;
}

/*****************************************************************/
/*                                                               */
/*  Getsig2cycles Function Description                           */
/*                                                               */
/*  The Getsig2cycles function is called whenever the user       */
/*  changes the value of the control for the number of cycles in */
/*  the second signal.  The function gets the new value of the   */
/*  control and puts it in the sig2cycles variable.              */
/*                                                               */
/*****************************************************************/

int CVICALLBACK Getsig2cycles (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            GetCtrlVal (mainpnl, MAINPNL_SIG2CYCLES, &sig2cycles);
            if (autoGenerateGraphs) GenerateGraphs();

            break;
        case EVENT_RIGHT_CLICK:
            MessagePopup ("Set Signal 2 Cycles",
                          "Sets the number of cycles in the second signal.");

            break;
    }
    return 0;
}

/*****************************************************************/
/*                                                               */
/*  Getsig2phase Function Description                            */
/*                                                               */
/*  The Getsig2phase function is called whenever the user        */
/*  changes the value of the control of the phase of the second  */
/*  signal.  The function gets the new value of the control and  */
/*  puts it in the sig2phase variable.                           */
/*                                                               */
/*****************************************************************/

int CVICALLBACK Getsig2phase (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            GetCtrlVal (mainpnl, MAINPNL_SIG2PHASE, &sig2phase);
            if (autoGenerateGraphs) GenerateGraphs();

            break;
        case EVENT_RIGHT_CLICK:
            MessagePopup ("Set Signal 2 Phase",
                          "Sets the phase offset of the second signal.");

            break;
    }
    return 0;
}

/*****************************************************************/
/*                                                               */
/*  Getsig2noise Function Description                            */
/*                                                               */
/*  The Getsig2noise function is called whenever the user        */
/*  changes the value of the control for the enable/disable      */
/*  switch for the noise on the second signal.  The function     */
/*  gets the new value of the control and puts it in the         */
/*  sig2noise variable.  If the noise is disabled, the function  */
/*  disables the noise level control for the second signal.  If  */
/*  the noise is enabled, the function enables the noise level   */
/*  control.                                                     */
/*                                                               */
/*****************************************************************/

int CVICALLBACK Getsig2noise (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            GetCtrlVal (mainpnl, MAINPNL_SIG2NOISE, &sig2noise);
            if (sig2noise == 0) {
               SetInputMode (mainpnl, MAINPNL_SIG2NOISEAMP, 0);
            }
            else {
               SetInputMode (mainpnl, MAINPNL_SIG2NOISEAMP, 1);
            }   
            if (autoGenerateGraphs) GenerateGraphs();
            break;
        case EVENT_RIGHT_CLICK:
            MessagePopup ("Enable/Disable Signal 2 Noise",
                          "Enables and disables the noise added to the second signal.");

            break;
    }
    return 0;
}

/*****************************************************************/
/*                                                               */
/*  Getsig2noiseamp Function Description                         */
/*                                                               */
/*  The Getsig2noiseamp function is called whenever the user     */
/*  changes the value of the control for the amplitude of the    */
/*  noise added to the second signal.  The function gets the new */
/*  value of the control and puts it in the sig2noiseamp         */
/*  variable.                                                    */
/*                                                               */
/*****************************************************************/

int CVICALLBACK Getsig2noiseamp (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            GetCtrlVal (mainpnl, MAINPNL_SIG2NOISEAMP, &sig2noiseamp);
            if (autoGenerateGraphs) GenerateGraphs();

            break;
        case EVENT_RIGHT_CLICK:
            MessagePopup ("Select Signal 2 Noise Amplitude",
                          "Sets the standard deviation of the Gaussian noise added to the second signal.");

            break;
    }
    return 0;
}

/*****************************************************************/
/*                                                               */
/*  Getsig2wavetype Function Description                         */
/*                                                               */
/*  The Getsig2wavetype function is called whenever the user     */
/*  changes the value of the control selecting the type of wave  */
/*  used for the second signal.  The function gets the new value */
/*  of the control and puts it in the sig2wavetype variable.     */
/*                                                               */
/*****************************************************************/

int CVICALLBACK Getsig2wavetype (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            GetCtrlVal (mainpnl, MAINPNL_SIG2WAVETYPE, &sig2wavetype);
            if (autoGenerateGraphs) GenerateGraphs();
            if (autoGenerateGraphs) GenerateGraphs();

            break;
        case EVENT_RIGHT_CLICK:
            MessagePopup ("Select Signal 2 Wave Type",
                          "Selects the type of wave used for the second signal - sine, square, or triangle.");

            break;
    }
    return 0;
}


int CVICALLBACK SetAutoGenerate (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_VAL_CHANGED:
            GetCtrlVal(panel, control ,&autoGenerateGraphs);

            break;
    }
    return 0;
}

/*****************************************************************/
/*                                                               */
/* Help Button Callback                                          */
/*                                                               */
/*****************************************************************/
int CVICALLBACK HelpCallback (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_RIGHT_CLICK:
        case EVENT_COMMIT:
            MessagePopup ("Correlation Function Example Program",HELP_MSG);
        break;
    }
    return 0;
}





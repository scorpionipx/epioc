/*****************************************************************/
/*                                                               */
/* Windowing Comparision Example Program                         */
/*                                                               */
/*****************************************************************/
#define HELP_MSG \
"This program is designed to serve as an example in how to use \n\
different windowing functions.  The effects of different types of window \n\
functions are best illustrated in the frequency domain.  This program \n\
combines two sinusoidal waveforms, one of which has an amplitude \n\
greater by a factor of 1000.  Looking at the frequency spectrum on \n\
a linear scale with no windowing applied, the higher amplitude waveform \n\
hides the lower amplitude waveform.   By applying the Hanning Window \n\
function to the combined waveform and displaying the spectrum in a dB \n\
format, the lower amplitude waveform is detectable."

#include <cvirte.h>     /* needed if linking executable in external compiler; harmless otherwise */
#include <utility.h>
#include <ansi_c.h>
#include <analysis.h>
#include <userint.h>
#include "windowng.h"

#define NUMPOINTS 512

static int panelHandle;
static double waveTime[2][NUMPOINTS], tempArray[NUMPOINTS], spectrum[NUMPOINTS];


void RedrawCalcAndDrawGraphs(void);

/****************************************************************/
/*                                                              */
/* Main Routine                                                 */
/*                                                              */
/****************************************************************/

int main (int argc, char *argv[])
{
    if (InitCVIRTE (0, argv, 0) == 0)    /* Needed if linking in external compiler; harmless otherwise */
        return -1;    /* out of memory */
    
    if ((panelHandle = LoadPanel (0, "windowng.uir", PANEL)) < 0)
        return -1;
    
    RedrawCalcAndDrawGraphs();
    
    DisplayPanel (panelHandle);
    RunUserInterface ();
	DiscardPanel (panelHandle);
    return 0;
}


/****************************************************************/
/*                                                              */
/* Recalculate the Output Graphs                                */
/*                                                              */
/****************************************************************/
int CVICALLBACK RecalcWaveforms (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_VAL_CHANGED:
                RedrawCalcAndDrawGraphs();
            break;
    }
    return 0;
}


/****************************************************************/
/*                                                              */
/* Recalculate the Output Graphs                                */
/*                                                              */
/****************************************************************/
void RedrawCalcAndDrawGraphs(void)
{
    double wave1Amp, wave2Amp, wave1Freq, wave2Freq, freqSpace;
    int windowing[2];
    int scaling, i, j;
    WindowConst constants;
    double zero = 0.0;
    
    /* Clear Plots */    
    DeleteGraphPlot (panelHandle, PANEL_FREQGRAPH,   -1, VAL_DELAYED_DRAW);
    DeleteGraphPlot (panelHandle, PANEL_TIMEGRAPH,   -1, VAL_DELAYED_DRAW);
    DeleteGraphPlot (panelHandle, PANEL_WINDOWGRAPH, -1, VAL_DELAYED_DRAW);
    
    /* Get User Inputs */    
    GetCtrlVal (panelHandle, PANEL_WAVE1AMP,    &wave1Amp);
    GetCtrlVal (panelHandle, PANEL_WAVE2AMP,    &wave2Amp);
    GetCtrlVal (panelHandle, PANEL_WAVE1FREQ,   &wave1Freq);
    GetCtrlVal (panelHandle, PANEL_WAVE2FREQ,   &wave2Freq);
    GetCtrlVal (panelHandle, PANEL_SCALE,       &scaling);
    GetCtrlVal (panelHandle, PANEL_DATAWINDOW1, &windowing[0]);
    GetCtrlVal (panelHandle, PANEL_DATAWINDOW2, &windowing[1]);

    /* Generate Signals */
    SineWave (NUMPOINTS, wave1Amp, wave1Freq/500, &zero, waveTime[0]);
    SineWave (NUMPOINTS, wave2Amp, wave2Freq/500, &zero, waveTime[1]);
    
    /* Add and Display Sum of Signals */
    Add1D (waveTime[0], waveTime[1], NUMPOINTS, tempArray);
    PlotY (panelHandle, PANEL_TIMEGRAPH, tempArray, (NUMPOINTS/100)*20+1,
           VAL_DOUBLE, VAL_THIN_LINE, VAL_NO_POINT, VAL_SOLID, 1, VAL_BLACK);

    /* Generate Display Window Data */       
    for (i=0;i<2;i++) {
        LinEv1D (tempArray, NUMPOINTS, 0, 1, tempArray);
        ScaledWindow (tempArray, NUMPOINTS, windowing[i], &constants);
        PlotY (panelHandle, PANEL_WINDOWGRAPH, tempArray, NUMPOINTS,
               VAL_DOUBLE, VAL_THIN_LINE, VAL_NO_POINT, VAL_SOLID, 1, (i)?VAL_BLUE:VAL_RED);
    }               
    
    /* Apply 2 Windows to Input Data and Display */
    for (i=0;i<2;i++) {
        Add1D (waveTime[0], waveTime[1], NUMPOINTS, tempArray);
        ScaledWindow (tempArray, NUMPOINTS, windowing[i], &constants);
        
        AutoPowerSpectrum (tempArray, NUMPOINTS, 1/1000.0, spectrum, &freqSpace);
        
        switch (scaling) {
            case 1:
                for (j=0; j<(NUMPOINTS/2); j++) 
                    spectrum[j] = 20*(log10(spectrum[j]));
                break;
        }
        PlotY (panelHandle, PANEL_FREQGRAPH, spectrum, NUMPOINTS/2,
               VAL_DOUBLE, VAL_THIN_LINE, VAL_NO_POINT, VAL_SOLID, 1, (i)?VAL_BLUE:VAL_RED);
    }
}


/****************************************************************/
/*                                                              */
/*  Quit Function                                               */
/*                                                              */
/*  The Quit function is called whenever the  user clicks on    */
/*  the Quit button.  The execution of the program is           */
/*  terminated.                                                 */
/*                                                              */
/****************************************************************/
int CVICALLBACK Quit (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            QuitUserInterface (0);

            break;
    }
    return 0;
}

/*****************************************************************/
/*                                                               */
/* Help Button Callback                                          */
/*                                                               */
/*****************************************************************/
int CVICALLBACK HelpCallback (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_RIGHT_CLICK:
        case EVENT_COMMIT:
            MessagePopup ("Windowing Comparision Example Program",HELP_MSG);
        break;
    }
    return 0;
}


/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                           1
#define  PANEL_FREQGRAPH                 2
#define  PANEL_TIMEGRAPH                 3
#define  PANEL_DATAWINDOW2               4       /* callback function: RecalcWaveforms */
#define  PANEL_DATAWINDOW1               5       /* callback function: RecalcWaveforms */
#define  PANEL_WINDOWGRAPH               6
#define  PANEL_QUIT                      7       /* callback function: Quit */
#define  PANEL_SCALE                     8       /* callback function: RecalcWaveforms */
#define  PANEL_HELP                      9       /* callback function: HelpCallback */
#define  PANEL_WAVE2AMP                  10      /* callback function: RecalcWaveforms */
#define  PANEL_WAVE2FREQ                 11      /* callback function: RecalcWaveforms */
#define  PANEL_WAVE1FREQ                 12      /* callback function: RecalcWaveforms */
#define  PANEL_WAVE1AMP                  13      /* callback function: RecalcWaveforms */
#define  PANEL_TEXTMSG_2                 14
#define  PANEL_TEXTMSG                   15


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */ 

int  CVICALLBACK HelpCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Quit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK RecalcWaveforms(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif

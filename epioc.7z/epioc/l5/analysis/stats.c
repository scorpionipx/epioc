/*----------------------------------------------------------------------------*/
/* Simple Statistics Example                                                  */
/*                                                                            */
/* Given that the data represents the mean time between failures in hours,    */
/* estimate when the next failure will occur with a variable confidence level */
/*----------------------------------------------------------------------------*/
#define HELP_MSG \
"This example will take the input data which represents the mean time between\n\
failures in hours and estimate when the next failure will occur with a variable\n\
confidence level."

/*----------------------------------------------------------------------------*/
/* Includes                                                                   */
/*----------------------------------------------------------------------------*/
#include <utility.h>
#include <userint.h>
#include <ansi_c.h>
#include <analysis.h>

#include "stats.h"

/*----------------------------------------------------------------------------*/
/* Variables                                                                  */
/*----------------------------------------------------------------------------*/
#define MAXPOINTS 100
static double result;
static double confidence;
double width,deviation;      
static double data;  
static int panelHandle;
double buffer[MAXPOINTS];
static int counter=0;
static double mean; 

/*----------------------------------------------------------------------------*/
/* Main                                                                       */
/*----------------------------------------------------------------------------*/
int main (int argc, char *argv[])
{
    if (InitCVIRTE (0, argv, 0) == 0)   /* Initialize CVI libraries */
        return -1;  /* out of memory */
    if ((panelHandle = LoadPanel (0, "stats.uir", PANEL)) < 0)
        return -1;
        
    Cls();      
    SetCtrlAttribute (panelHandle, PANEL_DONE, ATTR_DIMMED, 1); 
    
    DisplayPanel (panelHandle);
    RunUserInterface ();
	DiscardPanel (panelHandle);
    return 0;
}

/*----------------------------------------------------------------------------*/
/* Quit                                                                       */
/*----------------------------------------------------------------------------*/
int CVICALLBACK Quit (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            QuitUserInterface (0);
            break;
    }
    return 0;
}
                                                                          
/*----------------------------------------------------------------------------*/
/* Accept                                                                     */
/*----------------------------------------------------------------------------*/
int CVICALLBACK Accept (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            GetCtrlVal (panelHandle, PANEL_DATA, &data);
            /* Enter Data  points and place into buffer */
            buffer[counter++]=data;
            
            /* Keep count of number of element being entered by user */
            SetCtrlVal (panelHandle, PANEL_SAMPLES, counter);  
            if (counter>1)
                SetCtrlAttribute (panelHandle, PANEL_DONE, ATTR_DIMMED, 0);
                
            /* predefined a max. buffer size of MAXPOINTS */
            if(counter>=MAXPOINTS) 
            {
                MessagePopup ("WARNING", "Do not enter any more data points");  
                SetCtrlAttribute (panelHandle, PANEL_ACCEPT_DATA, ATTR_DIMMED, 1);
            }    
                
            break;
    }
    return 0;
}


/*----------------------------------------------------------------------------*/
/* Done                                                                       */
/*----------------------------------------------------------------------------*/
int CVICALLBACK Done (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    char meanBuf[132];
    double probability;
    switch (event) {
        case EVENT_COMMIT:
            /* Get confidence */
            GetCtrlVal (panelHandle, PANEL_CONFIDENCE, &confidence);
            
            /* Calculate values */
            probability=((1-confidence)/2)+confidence;
            InvT_Dist (probability, counter-1, &result);   
            StdDev (buffer, counter, &mean, &deviation);
            width=deviation*(result*1/(sqrt (counter)));
            
            /* Display values */                
            SetCtrlAttribute (panelHandle, PANEL_OUTPUT, ATTR_DIMMED, 0);  
            SetCtrlVal (panelHandle, PANEL_FREEDOM, counter-1);  
            SetCtrlVal (panelHandle, PANEL_DEVIATION,deviation);
            
            sprintf(meanBuf, "%f +/- %f", mean, width);            
            SetCtrlVal (panelHandle, PANEL_MEAN, meanBuf);
            break;
    }
    return 0;
}

/*----------------------------------------------------------------------------*/
/* OutputToSTDIO                                                              */
/*----------------------------------------------------------------------------*/
int CVICALLBACK OutputToSTDIO (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    int i;
    switch (event) {
        case EVENT_COMMIT:
#if _NI_mswin_
            SetStdioWindowVisibility (1);
#endif
            printf("Data Values:\n");
            for (i=0;i<counter;i++) 
                printf("  %f\n",buffer[i]);
                
            printf("Mean=%f, Standard deviation=%f\n",mean,deviation); 
            
            break;
    }
    return 0;
}

/*----------------------------------------------------------------------------*/
/* Help                                                                       */
/*----------------------------------------------------------------------------*/
int CVICALLBACK HelpCallback (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_RIGHT_CLICK:
        case EVENT_COMMIT:
            MessagePopup ("Confidence Interval Example",HELP_MSG);
        break;
    }
    return 0;
}

/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                            1
#define  PANEL_UPDATE                     2       /* control type: command, callback function: RecalcWaveforms */
#define  PANEL_HELP                       3       /* control type: command, callback function: HelpCallback */
#define  PANEL_QUIT                       4       /* control type: command, callback function: Quit */
#define  PANEL_TEXTMSG_NUMTAP             5       /* control type: textMsg, callback function: (none) */
#define  PANEL_NUMTAP_FIR                 6       /* control type: numeric, callback function: (none) */
#define  PANEL_NUMTAP_IFIR                7       /* control type: numeric, callback function: (none) */
#define  PANEL_SAMP_FREQ                  8       /* control type: numeric, callback function: (none) */
#define  PANEL_FILTER_TYPE                9       /* control type: ring, callback function: FilterTypeCallback */
#define  PANEL_PASSBAND_FREQ              10      /* control type: numeric, callback function: (none) */
#define  PANEL_STOPBAND_FREQ              11      /* control type: numeric, callback function: (none) */
#define  PANEL_RIPPLE                     12      /* control type: numeric, callback function: (none) */
#define  PANEL_ATTENUATION                13      /* control type: numeric, callback function: (none) */
#define  PANEL_CENTER_FREQ                14      /* control type: numeric, callback function: (none) */
#define  PANEL_SCALE                      15      /* control type: slide, callback function: RecalcWaveforms */
#define  PANEL_WRAP                       16      /* control type: textButton, callback function: RecalcWaveforms */
#define  PANEL_MAG_RESPONSE               17      /* control type: graph, callback function: (none) */
#define  PANEL_PHASE_RESPONSE             18      /* control type: graph, callback function: (none) */


     /* Control Arrays: */

          /* (no control arrays in the resource file) */


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK FilterTypeCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK HelpCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Quit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK RecalcWaveforms(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif

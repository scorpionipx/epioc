/*----------------------------------------------------------------------------*/
/* Using FFT to do a 2D FFT                                                   */
/*----------------------------------------------------------------------------*/
#define HELP_MSG \
"This example will demonstrate the use of the FFT function to calculate\n\
a 2D-FFT.  Given that the data represents the width and the delay of two\n\
signals this program calculates the 2D-FFT and displays the result on an\n\
intensity graph. Note that the results are Nyquist shifted so that low\n\
frequencies appear in the center."

/*----------------------------------------------------------------------------*/
/* Includes                                                                   */
/*----------------------------------------------------------------------------*/
#include <ansi_c.h>
#include <analysis.h>
#include <userint.h>

#include "2dfft.h"

/*----------------------------------------------------------------------------*/
/* Variables                                                                  */
/*----------------------------------------------------------------------------*/
double *Re2D_FFT, *Im2D_FFT, *magnitude;
double *inputbuff, *outputbuff;
double *iminputbuff, *imoutputbuff;

int panelHandle;
int size;
ColorMapEntry colors[8];
AnalysisLibErrType status; 

/*----------------------------------------------------------------------------*/
/* Prototypes                                                                 */
/*----------------------------------------------------------------------------*/
void Magnitude (void);
void RealFFTarray(void);
AnalysisLibErrType ImFFTarray(void);

/*----------------------------------------------------------------------------*/
/* Main                                                                       */
/*----------------------------------------------------------------------------*/
int main (int argc, char *argv[])
{
    if (InitCVIRTE (0, argv, 0) == 0)   /* Initialize CVI libraries */
        return -1;  /* out of memory */
    if ((panelHandle = LoadPanel (0, "2dfft.uir", PANEL)) < 0)
        return -1;
	SetCtrlAttribute (panelHandle, PANEL_CALCULATING, ATTR_ON_COLOR,
					  VAL_RED);
        
    /* Run UIR */   
    DisplayPanel (panelHandle);
    RunUserInterface ();
    DiscardPanel (panelHandle);
    return 0;
}

/*----------------------------------------------------------------------------*/
/* Calculate 2D FFT                                                           */
/*----------------------------------------------------------------------------*/
int CVICALLBACK Go (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    double *xarray, *yarray;
    int width_y;
    int width_x;
    int delay_y;
    int delay_x;    
    
    switch (event) {
        case EVENT_COMMIT:
            GetCtrlVal (panelHandle, PANEL_DELAY_X, &delay_x);
            GetCtrlVal (panelHandle, PANEL_DELAY_Y, &delay_y);
            GetCtrlVal (panelHandle, PANEL_WIDTH_X, &width_x);
            GetCtrlVal (panelHandle, PANEL_WIDTH_Y, &width_y);
            GetCtrlVal (panelHandle, PANEL_SIZE, &size);
            
            /* Clear Plots */
            DeleteGraphPlot (panelHandle, PANEL_IMAGE, -1, VAL_IMMEDIATE_DRAW);
            DeleteGraphPlot (panelHandle, PANEL_2DFFT, -1, VAL_IMMEDIATE_DRAW);
            
            if((delay_x+width_x)>size | (delay_y+width_y)>size) 
                MessagePopup ("Input Error", "NOTE: DELAY+WIDTH>SIZE");
            else
            {   
                ssize_t minArrayI, maxArrayI;
                double minArrayV, maxArrayV;
                
                /* Allocate memory */
                xarray = calloc (size, sizeof(double));
                yarray = calloc (size, sizeof(double));
                
                magnitude    = calloc (size*size, sizeof(double));
                inputbuff    = calloc (size*size, sizeof(double));
                outputbuff   = calloc (size*size, sizeof(double));
                iminputbuff  = calloc (size*size, sizeof(double));
                imoutputbuff = calloc (size*size, sizeof(double));
                
                /* Calculate Image */
                Pulse (size, 1.00, delay_x, width_x, xarray);
                Pulse (size, 1.00, delay_y, width_y, yarray);
                OuterProduct (xarray, size, yarray, size, inputbuff);
                
            
                /* Set up color map array for two colors 	*/
                /* Assigns colors to specific values 		*/
                colors[0].dataValue.valDouble = (0.0);
                colors[0].color = MakeColor (0, 0, 0);
                colors[1].dataValue.valDouble = (1);
                colors[1].color = MakeColor (255, 255, 255);

                                 
                /* Plot Input Image */
				PlotIntensity (panelHandle, PANEL_IMAGE, inputbuff, size, size,
							   VAL_DOUBLE, colors, VAL_BLACK, 2, 1, 0);
                               
                /* Perform 2D FFT */
                
				SetCtrlVal (panelHandle, PANEL_CALCULATING, 1);
                
                RealFFTarray();
                Transpose (inputbuff, size, size, outputbuff);
                Transpose (iminputbuff, size, size, imoutputbuff);
                ImFFTarray(); 
                Magnitude();
                SetCtrlVal (panelHandle, PANEL_CALCULATING, 0);
                
                /* Find maximums and minimums of magnitude for use in building */
                /* color map */
				MaxMin1D (magnitude, size*size, &maxArrayV, &maxArrayI, &minArrayV,
						  &minArrayI);
                
                /* set up color map array for FFT output */
                /* Assigns colors to specific values */
                colors[0].dataValue.valDouble = (minArrayV);
                colors[0].color = MakeColor (0, 0, 0);
                colors[1].dataValue.valDouble = (minArrayV + .16667 * maxArrayV);
                colors[1].color = MakeColor (0, 0, 255);
                colors[2].dataValue.valDouble = (minArrayV + 2 * 0.1429 * maxArrayV);
                colors[2].color = MakeColor (0, 255, 255);
                colors[3].dataValue.valDouble = (minArrayV + 3 * 0.1429 * maxArrayV);
                colors[3].color = MakeColor (0, 255, 0);
                colors[4].dataValue.valDouble = (minArrayV + 4 * 0.1429 * maxArrayV);
                colors[4].color = MakeColor (255, 255, 0);
                colors[5].dataValue.valDouble = (minArrayV + 5 * 0.1429 * maxArrayV);
                colors[5].color = MakeColor (255, 0, 0);
                colors[6].dataValue.valDouble = (minArrayV + 6 * .1429 * maxArrayV);
                colors[6].color = MakeColor (255, 0, 255);
                colors[7].dataValue.valDouble = (maxArrayV);
                colors[7].color = MakeColor (255, 255, 255);
                
                /* Plot 2D FFT */                
                PlotIntensity (panelHandle, PANEL_2DFFT, magnitude, size, size,
                                 VAL_DOUBLE, colors, VAL_BLACK, 8, 1, 1);
                                 
                /* Release memory */
                free(xarray);
                free(yarray);

                free(magnitude);   
                free(inputbuff);   
                free(outputbuff);  
                free(iminputbuff); 
                free(imoutputbuff);
            }                      
            break;
    }
    return 0;
}

/*----------------------------------------------------------------------------*/
/* RealFFTarray                                                               */
/*----------------------------------------------------------------------------*/
/* Real 2D array is passed and 1D realFFT is performed rowwise.               */
/* This results in a real matrix and an imaginary matrix.                     */
/*----------------------------------------------------------------------------*/
 void RealFFTarray(void)    
{
    double *inter1, *inter2;
    int i,j,index;
    
    inter1   = calloc (size, sizeof(double));
    inter2   = calloc (size, sizeof(double)); 
    
    for (i=0;i<size;i++)
    {
        for(j=0;j<size;j++)
        {
            index = i*size+j;
            inter1[j]=inputbuff[index];
        }    
        ReFFT (inter1, inter2, size);
        for(j=0;j<size;j++)
        {
            index = i*size+j;
            inputbuff[index]=inter1[j];
            iminputbuff[index]=inter2[j];
        }
    }
    
    free(inter1);  
    free(inter2);   
}

/*----------------------------------------------------------------------------*/
/* ImFFTarray                                                                 */
/*----------------------------------------------------------------------------*/
/* Real/Imaginary component arrays are passed and 1D FFT is performed rowwise */
/* This results in a real matrix and an imaginary matrix                      */
/*----------------------------------------------------------------------------*/
AnalysisLibErrType ImFFTarray(void)
{
    double *inter1, *inter2;
    int i,j,index;

    
    inter1 = calloc (size, sizeof(double));
    inter2 = calloc (size, sizeof(double)); 
    
    for (i=0;i<size;i++)
    {

        for(j=0;j<size;j++)
        {
            index = i*size+j;
            inter1[j]=outputbuff[index];
            inter2[j]=imoutputbuff[index];
        }
        status = FFT (inter1, inter2, size);
        for(j=0;j<size;j++)
        {
            index = i*size+j;
            outputbuff[index]=inter1[j];
            imoutputbuff[index]=inter2[j];
        }
    }
    
    free(inter1);  
    free(inter2);
    return status;
}

/*----------------------------------------------------------------------------	*/
/* Magnitude - Calculates the magnetude of the elements of the resulting 2DFFT	*/
/* Results are Nyquist-shifted to center of matrix for display 					*/
/*----------------------------------------------------------------------------	*/
void Magnitude (void)
{
    int i,j,index, r, c; 
    int s2 = size/2;
   
    c = s2;
    r = s2;
    
    for (i=0;i<size;i++)
    {
    	if (i >= s2) c = -s2;
    	r = s2;
        for(j=0;j<size;j++)
        {
        	if (j >= s2) r = -s2;
            index = i*size + j;
            magnitude[index + r + size * c] 
            	= sqrt(outputbuff[index]*outputbuff[index]+imoutputbuff[index]*imoutputbuff[index]);
        }
    }
}

/*----------------------------------------------------------------------------*/
/* Quit                                                                       */
/*----------------------------------------------------------------------------*/
int CVICALLBACK Quit (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            QuitUserInterface (0);
            break;
    }
    return 0;
}

/*----------------------------------------------------------------------------*/
/* Help                                                                       */
/*----------------------------------------------------------------------------*/
int CVICALLBACK Help (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_RIGHT_CLICK:
        case EVENT_COMMIT:
            MessagePopup ("Calculate 2D FFT",HELP_MSG);
            break;
    }
    return 0;
}

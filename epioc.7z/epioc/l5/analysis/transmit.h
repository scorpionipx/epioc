/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                           1
#define  PANEL_F_Order                   2
#define  PANEL_SAMPLES                   3
#define  PANEL_NOISE                     4
#define  PANEL_GRAPH                     5
#define  PANEL_COMMANDBUTTON             6       /* callback function: Compute */
#define  PANEL_COMMANDBUTTON_2           7       /* callback function: Displayhelp */
#define  PANEL_QUIT                      8       /* callback function: Quit */
#define  PANEL_TEXTMSG_2                 9
#define  PANEL_TEXTMSG                   10
#define  PANEL_DECORATION                11


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */ 

int  CVICALLBACK Compute(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Displayhelp(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Quit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif

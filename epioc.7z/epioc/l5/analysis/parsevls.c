/*----------------------------------------------------------------------------*/
/* Parseval's theorem                                                         */
/*----------------------------------------------------------------------------*/
#define HELP_MSG \
"This program illustrates Parseval's theorem which states that the sum of \n\
the time and frequency domain contents of a signal are equal.\n\
It uses the following categories of functions: \n\
\n\
  Signal Generation\n\
  Array Manipulation\n\
  Complex number manipulation\n\
  FFT\n"        

/*----------------------------------------------------------------------------*/
/* Includes                                                                   */
/*----------------------------------------------------------------------------*/
#include <utility.h>
#include <analysis.h>
#include <userint.h>

#include "parsevls.h"

/*----------------------------------------------------------------------------*/
/* Variables                                                                  */
/*----------------------------------------------------------------------------*/
#define POINTS 1024
static int secs;
static int mins;
static int hours;       
static double freqsum;
static double phase[POINTS];
static double magnitude[POINTS];
static double timesum;
static double squarednoise[POINTS];
static double noisearray[POINTS];
static char status = 0;

static int panelHandle;

/*----------------------------------------------------------------------------*/
/* Main                                                                       */
/*----------------------------------------------------------------------------*/
int main (int argc, char *argv[])
{
    if (InitCVIRTE (0, argv, 0) == 0)   /* Needed if linking in external compiler; harmless otherwise */
        return -1;  /* out of memory */
    if ((panelHandle = LoadPanel (0, "parsevls.uir", PANEL)) < 0)
        return -1;
    DisplayPanel (panelHandle);
    RunUserInterface ();
	DiscardPanel (panelHandle);
    return 0;
}

/*----------------------------------------------------------------------------*/
/* Go                                                                         */
/*----------------------------------------------------------------------------*/
int CVICALLBACK Go (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
        
            {
				if(status)
				{
					SetCtrlAttribute (panelHandle, PANEL_GO, ATTR_LABEL_TEXT, "Start calcul");
					status = 0;
				}
				else
				{
					SetCtrlAttribute (panelHandle, PANEL_GO, ATTR_LABEL_TEXT, "Stop calcul");
					status = 1;
				}
            	break;
			}
    }
    return 0;
}

/*----------------------------------------------------------------------------*/
/* Quit                                                                       */
/*----------------------------------------------------------------------------*/
int CVICALLBACK Quit (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            QuitUserInterface (0);
            break;
    }
    return 0;
}

/*----------------------------------------------------------------------------*/
/* Help                                                                       */
/*----------------------------------------------------------------------------*/
int CVICALLBACK HelpCallback (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_RIGHT_CLICK:
        case EVENT_COMMIT:
            MessagePopup ("Illustrate Parseval's theorem",HELP_MSG);
        break;
    }
    return 0;
}

int CVICALLBACK fTIMER (int panel, int control, int event,
						void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_TIMER_TICK:

			{
				if(status)
				{
		            /* Generate signal */
					#ifdef _NI_mswin_
					     GetSystemTime (&hours, &mins, &secs);
					#else
					     secs = time(NULL);
					#endif
			        WhiteNoise (POINTS, 1.0, secs, noisearray);
            
		            /* Plot signal */           
		            DeleteGraphPlot (panelHandle, PANEL_GRAPH, -1, VAL_DELAYED_DRAW);
		            PlotY (panelHandle, PANEL_GRAPH, noisearray, POINTS,
		                   VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID,
		                   1, VAL_RED);
            
		            /* Calculate one side */
		            Mul1D (noisearray, noisearray, POINTS, squarednoise);
		            Sum1D (squarednoise, POINTS, &timesum);
		            SetCtrlVal (panelHandle, PANEL_TIME, timesum);
    
		            /* Calculate other side */
		            Clear1D (squarednoise, POINTS);
		            FFT (noisearray, squarednoise, POINTS);
		            ToPolar1D (noisearray, squarednoise, POINTS, magnitude, phase);
		            Mul1D (magnitude, magnitude, POINTS, squarednoise);  
		            Sum1D (squarednoise, POINTS, &freqsum);
		            freqsum /= POINTS;
    
		            /* Update Display */
		            SetCtrlVal(panelHandle, PANEL_FREQ, freqsum);
				}
				break;
			}
	}
	return 0;
}

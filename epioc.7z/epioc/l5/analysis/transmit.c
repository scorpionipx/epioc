/*----------------------------------------------------------------------------*/
/* This example simply simulates a transmission and receiver system.          */
/* The example uses signal generation, 1D array manipulation and IIR          */
/* filtering functions.                                                       */
/*----------------------------------------------------------------------------*/

#define HELP_MSG \
"This example simply simulates a transmission and receiver system.\n\
\n\
The components of the system are as follows:\n\
  Transmitter:  Generates a modulated signal of a Pulse\n\
  Receiver:     Heterodyne receiver\n\
\n\
The received signal is filtered using a Bessel IIR Cascade filter."

/*----------------------------------------------------------------------------*/
/* Includes                                                                   */
/*----------------------------------------------------------------------------*/
#include <userint.h>
#include <analysis.h>
#include <ansi_c.h>

#include "transmit.h"

/*----------------------------------------------------------------------------*/
/* Variables                                                                  */
/*----------------------------------------------------------------------------*/
static int panelHandle;
static int NumSamples;

/*----------------------------------------------------------------------------*/
/* Main                                                                       */
/*----------------------------------------------------------------------------*/
int main (int argc, char *argv[])
{
    if (InitCVIRTE (0, argv, 0) == 0)   /* Initialize CVI libraries */
        return -1;  /* out of memory */
    if ((panelHandle = LoadPanel (0, "transmit.uir", PANEL)) < 0)
        return -1;
        
    DisplayPanel (panelHandle);
    RunUserInterface ();
	DiscardPanel (panelHandle);
    return 0;
}

/*----------------------------------------------------------------------------*/
/* Transmitter - Generate modulated pulse                                     */
/*----------------------------------------------------------------------------*/
void Transmitter(int NumSamples, double *pulsepattern)
{
    /* Generate modulated pulse */
    double *temp;

    temp = malloc(sizeof(double)*NumSamples);
    Pulse (NumSamples, 1.0, 64, 128, pulsepattern);
    
    /* Plot original pulse */
    PlotY (panelHandle, PANEL_GRAPH, pulsepattern, NumSamples,
           VAL_DOUBLE, VAL_CONNECTED_POINTS, VAL_NO_POINT,
           VAL_SOLID, 1, VAL_BLUE);
           
    /* Modulate */           
    SinePattern (NumSamples, 1.0, 0.0, (NumSamples >> 2), temp);
    Mul1D (temp, pulsepattern, NumSamples, pulsepattern);

    free(temp);
}


/*----------------------------------------------------------------------------*/
/* Receiver                                                                   */
/*----------------------------------------------------------------------------*/
void Receiver(int NumSamples, double *pulsepattern, double *Output)
{
    double *temp;

    temp = malloc(sizeof(double)*NumSamples);
    
    SinePattern (NumSamples, 2.0, 0.0, (NumSamples >> 2), temp); 
    Mul1D (temp, pulsepattern, NumSamples, Output);
    free(temp);
}



/*----------------------------------------------------------------------------*/
/* Compute                                                                    */
/*----------------------------------------------------------------------------*/
int CVICALLBACK Compute (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    IIRFilterPtr BessPtr;
    int Filt_ord;
    double *Noise , *pulsepattern, *Output, *FiltData;
    double NoiseAmp;

    switch (event) {
        case EVENT_COMMIT:
        
            DeleteGraphPlot (panelHandle, PANEL_GRAPH, -1, VAL_IMMEDIATE_DRAW);
            GetCtrlVal (panelHandle, PANEL_SAMPLES, &NumSamples);
            GetCtrlVal (panelHandle, PANEL_NOISE, &NoiseAmp);
            GetCtrlVal (panelHandle, PANEL_F_Order, &Filt_ord);
            
            /* Allocate arrays to store data */
            pulsepattern = malloc(NumSamples*sizeof(double));
            Noise = malloc(NumSamples*sizeof(double));
            Output = malloc(NumSamples*sizeof(double));
            FiltData = malloc(NumSamples*sizeof(double));
            
            /* Generate modulated pulse waveform */
            Transmitter(NumSamples,pulsepattern);
                                                                     
            /* Add Noise to simulate transmission */
            WhiteNoise (NumSamples, NoiseAmp, 0, Noise);
            Add1D (pulsepattern, Noise, NumSamples, pulsepattern);
            
            /* Apply heterodyne receiver */
            Receiver(NumSamples, pulsepattern,Output);
            
            /* Apply Bessel filter */
            BessPtr = AllocIIRFilterPtr (LOWPASS, Filt_ord);
            Bessel_CascadeCoef (1.0, 0.1250, 0.45, BessPtr);
            IIRCascadeFiltering (Output, NumSamples, BessPtr, FiltData);
            FreeIIRFilterPtr (BessPtr);

            /* Plot filtered data */
            PlotY (panelHandle, PANEL_GRAPH, FiltData, NumSamples,
                   VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID,
                   1, VAL_RED);
                   
            /* Release memory */
            free(pulsepattern);
            free(Noise);
            free(FiltData);
            free(Output);
            
            break;
    }
    return 0;
}

/*----------------------------------------------------------------------------*/
/* Help Button Callback                                                       */
/*----------------------------------------------------------------------------*/
int CVICALLBACK Displayhelp (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{

    switch (event) {
        case EVENT_RIGHT_CLICK:
        case EVENT_COMMIT:
            MessagePopup ("Transmit/Receiver System", HELP_MSG);
        break;
    }
    return 0;
}

/*----------------------------------------------------------------------------*/
/* Quit                                                                       */
/*----------------------------------------------------------------------------*/
int CVICALLBACK Quit (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            QuitUserInterface(0);
            
            break;
    }
    return 0;
}

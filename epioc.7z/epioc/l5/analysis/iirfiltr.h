/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                           1
#define  PANEL_Design                    2       /* callback function: RunProgram */
#define  PANEL_Type                      3       /* callback function: RunProgram */
#define  PANEL_Ripple                    4       /* callback function: RunProgram */
#define  PANEL_Attentuation              5       /* callback function: RunProgram */
#define  PANEL_Order                     6       /* callback function: RunProgram */
#define  PANEL_Display                   7       /* callback function: RunProgram */
#define  PANEL_SamplingRate              8       /* callback function: RunProgram */
#define  PANEL_HCF                       9       /* callback function: RunProgram */
#define  PANEL_LCF                       10      /* callback function: RunProgram */
#define  PANEL_GRAPH1                    11
#define  PANEL_GRAPH2                    12
#define  PANEL_RUN                       13      /* callback function: RunProgram */
#define  PANEL_HELP                      14      /* callback function: Help */
#define  PANEL_QUIT                      15      /* callback function: QuitProgram */
#define  PANEL_AUTO                      16      /* callback function: AutoChange */


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */ 

int  CVICALLBACK AutoChange(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Help(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK QuitProgram(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK RunProgram(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif

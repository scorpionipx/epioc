/*****************************************************************/
/*                                                               */
/* Narrowband Filtering Example Program                          */
/*                                                               */
/*****************************************************************/
#define HELP_MSG \
"This program is designed to serve as an example in how to use narrowband \n\
filtering functions to design a narrowband FIR filter whose magnitude \n\
response is narrowband and whose phase response is linear. It also \n\
estimates the number of coefficients required by conventional FIR design \n\
techniques (such as the Parks-McClellan algorithm) for comparison with \n\
the number required by the Interpolated Finite Impulse Response (IFIR) \n\
filter design technique."

//==============================================================================
// Include files


#include <cvirte.h>     /* needed if linking executable in external compiler; harmless otherwise */
#include <utility.h>
#include <ansi_c.h>
#include <analysis.h>
#include <userint.h>
#include "narrowbandfilter.h"
#include "toolbox.h"  

static int panelHandle;

int UpdateDefValues(void);
int RedrawCalcAndDrawGraphs(void);
 
/****************************************************************/
/*                                                              */
/* Main Routine                                                 */
/*                                                              */
/****************************************************************/
int main (int argc, char *argv[])
{
    if (InitCVIRTE (0, argv, 0) == 0)    /* Needed if linking in external compiler; harmless otherwise */
        return -1;    /* out of memory */
    
    if ((panelHandle = LoadPanel (0, "narrowbandfilter.uir", PANEL)) < 0)
        return -1;

	UpdateDefValues();
    RedrawCalcAndDrawGraphs();
    
    DisplayPanel (panelHandle);
    RunUserInterface ();
    DiscardPanel (panelHandle);
    return 0;
}

/*****************************************************************/
/*                                                               */
/* Filter Type Control Callback                                  */
/*                                                               */
/*****************************************************************/
int CVICALLBACK FilterTypeCallback (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_VAL_CHANGED:
			UpdateDefValues();
        break;
    }
    return 0;
}

/****************************************************************/
/*                                                              */
/* Update Default Values For Different Filter Types             */
/*                                                              */
/****************************************************************/
int UpdateDefValues(void)
{
    double freq_passband, freq_stopband, freq_center;
	int filterType;
	int error = 0;

	/* Get User Inputs */    
    GetCtrlVal(panelHandle, PANEL_FILTER_TYPE, 	&filterType);
	
	/* Update the Default Values for Passband, Stopband and Center Freq */
	switch(filterType){
		case 0:	/* lowpass filter */
		case 2: /* bandpass filter */
				freq_passband = 100.0;
				freq_stopband = 200.0;
				freq_center = 150.0;
				break;
				
		case 1: /* highpass filter */
		case 3: /* bandstop filter */
				freq_passband = 200.0;
				freq_stopband = 100.0;
				freq_center = 150.0;
				break;
				
		default:
				freq_passband = 100.0;
				freq_stopband = 200.0;
				freq_center = 150.0;
				break;
	}
	
	/* Show Center Freq Control only when Filter Type is Bandpass or Bandstop */
	if(filterType == 2 || filterType == 3){		/* bandpass or bandstop filter */
		errChk(SetCtrlAttribute(panelHandle, PANEL_CENTER_FREQ, ATTR_VISIBLE, 1));
	}
	else{
		errChk(SetCtrlAttribute(panelHandle, PANEL_CENTER_FREQ, ATTR_VISIBLE, 0));
	}	
	
	errChk(SetCtrlVal(panelHandle, PANEL_PASSBAND_FREQ, freq_passband));
	errChk(SetCtrlVal(panelHandle, PANEL_STOPBAND_FREQ, freq_stopband));
	errChk(SetCtrlVal(panelHandle, PANEL_CENTER_FREQ, freq_center));

Error:
	return error;
}

/****************************************************************/
/*                                                              */
/* Recalculate the Output Graphs                                */
/*                                                              */
/****************************************************************/
int CVICALLBACK RecalcWaveforms (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
		case EVENT_VAL_CHANGED:
                RedrawCalcAndDrawGraphs();
            break;
    }
    return 0;
}


/****************************************************************/
/*                                                              */
/* Recalculate the Output Graphs                                */
/*                                                              */
/****************************************************************/
int RedrawCalcAndDrawGraphs(void)
{
    double samp_freq, freq_passband, freq_stopband, freq_center, passband_ripple, stopband_attenuation;
	double delta, rs;
	int filterType;
	int scalingType, wrapMode;
	
	int numtaps_FIR, numtaps_IFIR;
	FIRCoefStruct coefinfo;
	
    double impulse = 1.0;
	int impulse_length = 1;
	
    int i;
	int length;
	int error = 0;

	double * impulse_response = NULL;
	NIComplexNumber * spectrum = NULL;
	double * magnitude_response = NULL;
	double * phase_response = NULL;
	double * plot_freq = NULL;

    /* Clear Plots */    
    DeleteGraphPlot(panelHandle, PANEL_MAG_RESPONSE,   -1, VAL_DELAYED_DRAW);
    DeleteGraphPlot(panelHandle, PANEL_PHASE_RESPONSE, -1, VAL_DELAYED_DRAW);

    /* Get User Inputs */    
    GetCtrlVal(panelHandle, PANEL_SAMP_FREQ,   		&samp_freq);
    GetCtrlVal(panelHandle, PANEL_PASSBAND_FREQ,   	&freq_passband);
    GetCtrlVal(panelHandle, PANEL_STOPBAND_FREQ,  	&freq_stopband);
    GetCtrlVal(panelHandle, PANEL_CENTER_FREQ,   	&freq_center);
    GetCtrlVal(panelHandle, PANEL_RIPPLE,       	&passband_ripple);
    GetCtrlVal(panelHandle, PANEL_ATTENUATION, 		&stopband_attenuation);
    GetCtrlVal(panelHandle, PANEL_FILTER_TYPE, 		&filterType);
    GetCtrlVal(panelHandle, PANEL_SCALE, 			&scalingType);                        
	GetCtrlVal(panelHandle, PANEL_WRAP, 			&wrapMode);                        
	
	/* Estimate and Display the Number of Coefficients Required by Conventional FIR Design Techniques */
	switch(filterType){
		case 0:	/* lowpass filter */
				delta = (freq_stopband - freq_passband) / samp_freq;
				break;
				
		case 1: /* highpass filter */
				delta = (freq_passband - freq_stopband) / samp_freq;
				break;
				
		case 2: /* bandpass filter */
				delta = (freq_stopband - freq_passband) * 0.5 / samp_freq;
				break;
				
		case 3: /* bandstop filter */
				delta = (freq_passband - freq_stopband) * 0.5 / samp_freq;
				break;
		
		default:
				delta = (freq_stopband - freq_passband) / samp_freq;
				break;		
	}
	
	rs = pow(10, - stopband_attenuation/20.0);
	numtaps_FIR = (int)((-20.0 * log( sqrt(passband_ripple * rs) ) - 13) / (14.6 * delta) * 1.1);
	
	errChk(SetCtrlVal(panelHandle, PANEL_NUMTAP_FIR, numtaps_FIR));
	
	/* Design a Narrowband FIR Filter */
	errChk(FIRNarrowBandCoef(samp_freq, freq_passband, freq_stopband, freq_center, passband_ripple, 
		stopband_attenuation, filterType, &coefinfo));

	/* Calculate and Display the Number of Coefficients Required by the Interpolated Finite Impulse Response (IFIR) Technique */
	numtaps_IFIR = coefinfo.Itaps + coefinfo.Mtaps;
	
	errChk(SetCtrlVal(panelHandle, PANEL_NUMTAP_IFIR, numtaps_IFIR));
	
	/* Calculate the Magnitude and Phase Response of the Narrowband FIR Filter */
	if(coefinfo.interp == 1){
		length = impulse_length + coefinfo.Mtaps - 1;
	}
	else{
		length = impulse_length + (coefinfo.Mtaps - 1) * coefinfo.interp + coefinfo.Itaps - 1;
	}
	
	nullChk(impulse_response = (double *)malloc(sizeof(double) * length));
	nullChk(spectrum = (NIComplexNumber *)malloc(sizeof(NIComplexNumber) * length));
	nullChk(magnitude_response = (double *)malloc(sizeof(double) * length));
	nullChk(phase_response = (double *)malloc(sizeof(double) * length));
	nullChk(plot_freq = (double *)malloc(sizeof(double) * (length/2)));
	
	errChk(FIRNarrowBandFilter(&impulse, impulse_length, coefinfo, impulse_response));
	
	errChk(FFTEx(impulse_response, length, -1, NULL, 0, spectrum));
	
	for(i = 0; i < length/2; i++){
		errChk(ToPolar(spectrum[i].real, spectrum[i].imaginary, &magnitude_response[i], &phase_response[i]));
		if(scalingType){
			magnitude_response[i] = log10(magnitude_response[i]) * 20.0;
		}
	}
	
	if(wrapMode){
		errChk(UnWrap1D(phase_response, length / 2));
	}
	
	/* Display the Magnitude and Phase Response of the Narrowband FIR Filter */
	errChk(Ramp(length/2, 0.0, (length/2 - 1) * samp_freq / length, plot_freq));

	PlotXY(panelHandle, PANEL_MAG_RESPONSE, plot_freq, magnitude_response, length/2,
               VAL_DOUBLE, VAL_DOUBLE, VAL_THIN_LINE, VAL_NO_POINT, VAL_SOLID, 1, VAL_RED);

	PlotXY(panelHandle, PANEL_PHASE_RESPONSE, plot_freq, phase_response, length/2,
               VAL_DOUBLE, VAL_DOUBLE, VAL_THIN_LINE, VAL_NO_POINT, VAL_SOLID, 1, VAL_RED);
	
Error:
	if(impulse_response)
		free(impulse_response);
	if(spectrum)
		free(spectrum);
	if(magnitude_response)
		free(magnitude_response);
	if(phase_response)
		free(phase_response);
	if(plot_freq)
		free(plot_freq);
	
	return error;
}

/****************************************************************/
/*                                                              */
/*  Quit Function                                               */
/*                                                              */
/*  The Quit function is called whenever the user clicks on     */
/*  the Quit button.  The execution of the program is           */
/*  terminated.                                                 */
/*                                                              */
/****************************************************************/
int CVICALLBACK Quit (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            QuitUserInterface (0);
            break;
    }
    return 0;
}

/*****************************************************************/
/*                                                               */
/* Help Button Callback                                          */
/*                                                               */
/*****************************************************************/
int CVICALLBACK HelpCallback (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_RIGHT_CLICK:
        case EVENT_COMMIT:
            MessagePopup ("Narrowband Filtering Example Program", HELP_MSG);
        break;
    }
    return 0;
}

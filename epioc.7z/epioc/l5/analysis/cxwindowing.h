/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                            1
#define  PANEL_TEXTMSG_I                  2       /* control type: textMsg, callback function: (none) */
#define  PANEL_WAVE1AMP                   3       /* control type: numeric, callback function: RecalcWaveforms */
#define  PANEL_WAVE1FREQ                  4       /* control type: numeric, callback function: RecalcWaveforms */
#define  PANEL_TEXTMSG_Q                  5       /* control type: textMsg, callback function: (none) */
#define  PANEL_WAVE2AMP                   6       /* control type: numeric, callback function: RecalcWaveforms */
#define  PANEL_WAVE2FREQ                  7       /* control type: numeric, callback function: RecalcWaveforms */
#define  PANEL_DATAWINDOW                 8       /* control type: ring, callback function: RecalcWaveforms */
#define  PANEL_WINDOWGRAPH                9       /* control type: graph, callback function: (none) */
#define  PANEL_TIMEGRAPH                  10      /* control type: graph, callback function: (none) */
#define  PANEL_FREQGRAPH                  11      /* control type: graph, callback function: (none) */
#define  PANEL_SCALE                      12      /* control type: slide, callback function: RecalcWaveforms */
#define  PANEL_HELP                       13      /* control type: command, callback function: HelpCallback */
#define  PANEL_QUIT                       14      /* control type: command, callback function: Quit */


     /* Control Arrays: */

          /* (no control arrays in the resource file) */


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK HelpCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Quit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK RecalcWaveforms(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif

/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                            1
#define  PANEL_FRAMESIZE                  2
#define  PANEL_RATE                       3
#define  PANEL_WINDOWTYPE                 4
#define  PANEL_FUNDFREQ                   5
#define  PANEL_HARMONICS                  6
#define  PANEL_THD                        7
#define  PANEL_THDNOISE                   8
#define  PANEL_HELP                       9       /* callback function: Help */
#define  PANEL_CALCULATE                  10      /* callback function: RunCalculation */
#define  PANEL_QUIT                       11      /* callback function: Quit */
#define  PANEL_APSGRAPH                   12
#define  PANEL_DECORATION                 13


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */ 

int  CVICALLBACK Help(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Quit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK RunCalculation(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif

/*----------------------------------------------------------------------------*/
/* Non_Linear Fit using the Levenberg-Marquardt method                        */
/*----------------------------------------------------------------------------*/
#define HELP_MSG \
"This is an example for the Non_Linear Fit using the Levenberg-Marquardt\n\
method. The input to the function is an exponential signal with some noise\n\
added to it.  We will simulate this noisy signal for the purpose of this\n\
example.\n\
\n\
The NonLinear fit function will then find the best fit for this noisy data\n\
and compute the coefficients that describe the fit.\n\
\n\
The input signal is a*exp(b*x)+c+(noise)."

/*----------------------------------------------------------------------------*/
/* Includes                                                                   */
/*----------------------------------------------------------------------------*/
#include <analysis.h>
#include <userint.h>
#include <ansi_c.h>
#include "nlinfit.h"

/*----------------------------------------------------------------------------*/
/* Variables                                                                  */
/*----------------------------------------------------------------------------*/
static int panelHandle;

/*----------------------------------------------------------------------------*/
/* Main                                                                       */
/*----------------------------------------------------------------------------*/
int main (int argc, char *argv[])
{
    if (InitCVIRTE (0, argv, 0) == 0)   /* Needed if linking in external compiler; harmless otherwise */
        return -1;  /* out of memory */
    if ((panelHandle = LoadPanel (0, "nlinfit.uir", PANEL)) < 0)
        return -1;
    DisplayPanel (panelHandle);
    RunUserInterface ();
	DiscardPanel (panelHandle);
    return 0;
}

/*----------------------------------------------------------------------------*/
/* MYfunction                                                                 */
/*----------------------------------------------------------------------------*/
double MYfunction(double x, double a[], int number_of_coefficients)
{
    double result;
    result = a[0]*exp(a[1]*x)+a[2];
    
    return result;
    
}

/*----------------------------------------------------------------------------*/
/* CalculateFit                                                               */
/*----------------------------------------------------------------------------*/
static int CalculateFit(void)
{
    double *x;
    double *y;
    double *z;
    double *noise;
    int number_of_samples;
    int number_of_coefficients;
    int err;
    int i;
    double *a;
    double mse;
    double noise_amplitude;

    number_of_coefficients = 3;
    err = GetCtrlVal (panelHandle, PANEL_NUMBER, &number_of_samples);
    if(err != NoAnlysErr) {
                        return err;
                     }
    
    err = GetCtrlVal (panelHandle, PANEL_NOISE, &noise_amplitude);
    if(err != NoAnlysErr) {
                        return err;
                     }
                     
    x = (double*)malloc(number_of_samples*sizeof(double));
    if(x == NULL){
                    err = -20001;
                    return err;
                 }
                 
    y = (double*)malloc(number_of_samples*sizeof(double));
    if(y == NULL){
                    err = -20001;
                    free(x);
                    return err;
                 }
                 
    noise = (double*)malloc(number_of_samples*sizeof(double));
    if(noise == NULL){
                        err = -20001;
                        free(x);
                        free(y);
                        return err;
                     }
    
    a = (double*)malloc(number_of_coefficients*sizeof(double));
    if(a == NULL){
                        err = -20001;
                        free(x);
                        free(y);
                        free(noise);
                        return err;
                 }
    
    a[0] = 2.0;
    a[1] = 0.0;
    a[2] = 4.0;
    err = WhiteNoise (number_of_samples, noise_amplitude, 0, noise);
    if(err != NoAnlysErr) {
                        free(x);
                        free(y);
                        free(noise);
                        free(a);
                        return err;
                     }
    
    z = (double*)malloc(number_of_samples*sizeof(double));
    if(z == NULL){
                        err = -20001;
                        free(x);
                        free(y);
                        free(noise);
                        free(a);
                        return err;
                 }
                     
    for(i = 0; i < number_of_samples; i++)
    {
        *(x+i) = i;
        *(y+i) = 1.0*exp(-0.1*i)+2.0+*(noise+i);
    }
    PlotY (panelHandle, PANEL_GRAPH, y, number_of_samples, VAL_DOUBLE, VAL_SCATTER,
           VAL_X, VAL_SOLID, 1, VAL_RED);
    
    err = NonLinearFitWithMaxIters (x, y, z, number_of_samples, 100, MYfunction, a,
                        number_of_coefficients, &mse);
    if(err != NoAnlysErr) {
                        free(x);
                        free(y);
                        free(z);
                        free(noise);
                        free(a);
                        return err;
                     }
                     
    PlotY (panelHandle, PANEL_GRAPH, z, number_of_samples, VAL_DOUBLE, VAL_THIN_LINE,
           VAL_EMPTY_SQUARE, VAL_SOLID, 1, VAL_RED);
           
    free(x);
    free(y);
    free(z);
    free(noise);
    free(a);
    return 0;      
}


/*----------------------------------------------------------------------------*/
/* Run                                                                        */
/*----------------------------------------------------------------------------*/
int CVICALLBACK Run (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
        CalculateFit();
        
        break;
    }
    return 0;
}

/*----------------------------------------------------------------------------*/
/* Quit                                                                       */
/*----------------------------------------------------------------------------*/
int CVICALLBACK Quit (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            QuitUserInterface(0);
            break;
    }
    return 0;
}

/*----------------------------------------------------------------------------*/
/* Help                                                                       */
/*----------------------------------------------------------------------------*/
int CVICALLBACK Help (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_RIGHT_CLICK:
        case EVENT_COMMIT:
            MessagePopup ("Non_Linear Fit Example",HELP_MSG);

            break;
    }
    return 0;
}

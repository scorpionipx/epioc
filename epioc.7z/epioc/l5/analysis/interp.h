/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                           1
#define  PANEL_GRAPH                     2       /* callback function: GraphCallback */
#define  PANEL_ACQ                       3       /* callback function: AcquirePoints */
#define  PANEL_STOPACQ                   4       /* callback function: StopAcquire */
#define  PANEL_GENERATE                  5       /* callback function: GeneratePoints */
#define  PANEL_POINTS                    6
#define  PANEL_INTERPOLATE               7       /* callback function: Interpolate */
#define  PANEL_INTERPOLATE_2             8       /* callback function: Interpolate_2 */
#define  PANEL_HELP                      9       /* callback function: HelpCallback */
#define  PANEL_STOP                      10      /* callback function: Quit */
#define  PANEL_INTERPTYPE                11
#define  PANEL_CHOOSEMSG                 12
#define  PANEL_DECORATION_2              13
#define  PANEL_DECORATION_3              14
#define  PANEL_TEXTMSG                   15
#define  PANEL_DECORATION                16
#define  PANEL_TEXTMSG_2                 17


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */ 

int  CVICALLBACK AcquirePoints(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK GeneratePoints(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK GraphCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK HelpCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Interpolate(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Interpolate_2(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Quit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK StopAcquire(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif

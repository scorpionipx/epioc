/*----------------------------------------------------------------------------*/
/* Data Conditionin for PolyFit                                               */
/*----------------------------------------------------------------------------*/
#define HELP_MSG \
"This example shows how data conditioning can help in obtaining good\n\
results using the General Polynomial Fit function.  In this example, the\n\
x values have a small range but a large offset (from the origin).  In other\n\
words, the x values are very large.\n\
\n\
Without conditioning the fitted signal does not match the input data.\n\
With conditioning the fitted signal closely matches the input data."

/*----------------------------------------------------------------------------*/
/* Includes                                                                   */
/*----------------------------------------------------------------------------*/
#include <analysis.h>
#include <ansi_c.h>
#include <userint.h>
#include "polyfit1.h"

/*----------------------------------------------------------------------------*/
/* Variables                                                                  */
/*----------------------------------------------------------------------------*/
static int panelHandle;
static int autoRun = 1;

/*----------------------------------------------------------------------------*/
/* Prototypes                                                                 */
/*----------------------------------------------------------------------------*/
static int CalculateFit(void);

/*----------------------------------------------------------------------------*/
/* Main                                                                       */
/*----------------------------------------------------------------------------*/
int main (int argc, char *argv[])
{
    if (InitCVIRTE (0, argv, 0) == 0)   /* Needed if linking in external compiler; harmless otherwise */
        return -1;  /* out of memory */
    if ((panelHandle = LoadPanel (0, "polyfit1.uir", PANEL)) < 0)
        return -1;
        
    CalculateFit();
    DisplayPanel (panelHandle);
    RunUserInterface ();
	DiscardPanel (panelHandle);
    return 0;
}

/*----------------------------------------------------------------------------*/
/* CalculateFit                                                               */
/*----------------------------------------------------------------------------*/
#define	MIN_NUM_SAMPLES	3
static int CalculateFit(void)
{
    double phase = 0.0;
	double initial = 1000000.0;
    int number_of_samples;
    int polynomial_order;
    double max;
    ssize_t imax;
    double min = 0.;
    ssize_t imin;
    int i;
    int condition_data;
    double *sine_wave;
    double *x_values;
    double *coefs;
    double *fitted_values;
    double mse;
    int err;
    
    GetCtrlVal(panelHandle, PANEL_ORDER, &polynomial_order);
    if (polynomial_order >= MIN_NUM_SAMPLES)
		SetCtrlAttribute (panelHandle, PANEL_SAMPLES, ATTR_MIN_VALUE, polynomial_order + 1);
	else
		SetCtrlAttribute (panelHandle, PANEL_SAMPLES, ATTR_MIN_VALUE, MIN_NUM_SAMPLES);
    
    GetCtrlVal(panelHandle, PANEL_SAMPLES, &number_of_samples);
    err = DeleteGraphPlot (panelHandle, PANEL_GRAPH, -1, VAL_IMMEDIATE_DRAW); 
    
    x_values = (double *)malloc(number_of_samples*sizeof(double));
    if(x_values == NULL) 
        return OutOfMemAnlysErr;
    sine_wave = (double *)malloc(number_of_samples*sizeof(double));
    if(sine_wave == NULL) 
    {
        free(x_values);
        return OutOfMemAnlysErr;
    }
    err = Ramp (number_of_samples, initial, initial+number_of_samples-1, x_values);
    if(err != NoAnlysErr) 
    {
        free(x_values);
        free(sine_wave);
        return err;
    }
    err = GetCtrlVal (panelHandle, PANEL_SHIFT, &condition_data);  
    
    /* If condition data is set equal to true, then shift the x values.  Find the minimum    
    amplitude element in x values and subtract that number from all the elements in the array */
    if(condition_data) 
    {
        err = MaxMin1D(x_values, number_of_samples, &max, &imax, &min, &imin);
        if(err != NoAnlysErr) 
        {
            free(x_values);
            free(sine_wave);
            return err;
        }
                          
        for(i = 0; i < number_of_samples; i++) 
            *(x_values+i) -= min;
    }
    err = SineWave (number_of_samples, 1.0, 1.0/(2.0*number_of_samples), &phase, sine_wave);
    if(err != NoAnlysErr) 
    {
        free(x_values);
        free(sine_wave);
        return err;
    }
    fitted_values = (double *)malloc(number_of_samples*sizeof(double));
    if(fitted_values == NULL) 
    {
        free(x_values);
        free(sine_wave);
        return err;
    }
                              
    coefs = (double *)malloc((polynomial_order+1)*sizeof(double));
    if(coefs == NULL) 
    {
        free(x_values);
        free(sine_wave);
        free(fitted_values);
        return err;
    }
    err = PolyFit (x_values, sine_wave, number_of_samples,
                   polynomial_order, fitted_values, coefs, &mse);
    if(err != NoAnlysErr) 
    {
        free(x_values);
        free(sine_wave);
        free(fitted_values);
        free(coefs);
        return err;
    }
    
    /* If the x data has been conditioned (shifted closer to the origin in this case), then shift
    the data back to its original offset.  Bringing back the data to its original state is very
    important for properly plotting the data.  The best fit is the same for the conditioned
    and unconditioned data, but the coefs are different.  
    */
    if(condition_data) 
        for(i = 0; i < number_of_samples; i++) 
            *(x_values+i) += min;
            
    SetCtrlVal(panelHandle, PANEL_MSE, mse);
    SetCtrlVal(panelHandle, PANEL_COEFS1, coefs[0]);
    SetCtrlVal(panelHandle, PANEL_COEFS2, coefs[1]);
    SetCtrlVal(panelHandle, PANEL_COEFS3, coefs[2]);
    SetCtrlAttribute (panelHandle, PANEL_GRAPH, ATTR_ACTIVE_YAXIS,
                      VAL_LEFT_YAXIS);
    PlotXY (panelHandle, PANEL_GRAPH, x_values, sine_wave, number_of_samples,
            VAL_DOUBLE, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE,
            VAL_SOLID, 1, VAL_RED);
            
    SetCtrlAttribute (panelHandle, PANEL_GRAPH, ATTR_ACTIVE_YAXIS,
                      VAL_RIGHT_YAXIS);
    PlotXY (panelHandle, PANEL_GRAPH, x_values, fitted_values, number_of_samples,
            VAL_DOUBLE, VAL_DOUBLE, VAL_THIN_LINE, VAL_EMPTY_SQUARE,
            VAL_SOLID, 1, VAL_BLUE);
    free(x_values);
    free(sine_wave);
    free(fitted_values);
    free(coefs);
    return 0;
}

/*----------------------------------------------------------------------------*/
/* Run                                                                        */
/*----------------------------------------------------------------------------*/
int CVICALLBACK RunProgram (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            if ((autoRun) || (control == PANEL_RUN))
                CalculateFit();
            
            break;
    }
    return 0;
}

/*----------------------------------------------------------------------------*/
/* Quit                                                                       */
/*----------------------------------------------------------------------------*/
int CVICALLBACK Quit (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            QuitUserInterface (0);
            break;
    }
    return 0;
}

/*----------------------------------------------------------------------------*/
/* Help                                                                       */
/*----------------------------------------------------------------------------*/
int CVICALLBACK Help (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_RIGHT_CLICK:
        case EVENT_COMMIT:
            MessagePopup ("Data Conditionin for PolyFit", HELP_MSG);
        break;
    }
    return 0;
}


int CVICALLBACK AutoChange (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event)
        {
        case EVENT_COMMIT:
            GetCtrlVal(panel, control, &autoRun);
            break;
        }
    return 0;
}

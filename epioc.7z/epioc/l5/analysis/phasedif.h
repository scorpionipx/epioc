/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  MAINPNL                         1
#define  MAINPNL_NUMPOINTS               2       /* callback function: Getnumpoints */
#define  MAINPNL_CYCLES                  3       /* callback function: Getcycles */
#define  MAINPNL_SIG1TXT                 4
#define  MAINPNL_SIG1AMP                 5       /* callback function: Getsig1amp */
#define  MAINPNL_SIG1PHASE               6       /* callback function: Getsig1phase */
#define  MAINPNL_SIG1IND                 7
#define  MAINPNL_SIG2TXT                 8
#define  MAINPNL_SIG2AMP                 9       /* callback function: Getsig2amp */
#define  MAINPNL_SIG2PHASE               10      /* callback function: Getsig2phase */
#define  MAINPNL_SIG2MAX                 11
#define  MAINPNL_SIG2IND                 12
#define  MAINPNL_PHASEDIFF               13
#define  MAINPNL_CHECKBOX                14      /* callback function: SetAutoGenerate */
#define  MAINPNL_HELP                    15      /* callback function: HelpCallback */
#define  MAINPNL_GENERATE                16      /* callback function: Generate */
#define  MAINPNL_QUIT                    17      /* callback function: Quit */
#define  MAINPNL_SIGGRAPH                18
#define  MAINPNL_SUMGRAPH                19
#define  MAINPNL_SIG1MAX                 20
#define  MAINPNL_CORRGRAPH               21
#define  MAINPNL_DECORATION1             22
#define  MAINPNL_DECORATION2             23
#define  MAINPNL_DECORATION              24


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */ 

int  CVICALLBACK Generate(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getcycles(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getnumpoints(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig1amp(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig1phase(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig2amp(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig2phase(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK HelpCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Quit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SetAutoGenerate(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif

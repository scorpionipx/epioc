/*----------------------------------------------------------------------------*/
/* Interpolation Example Program                                              */
/*----------------------------------------------------------------------------*/
#define HELP_MSG_1 \
"This program is designed to serve as an example of how to\n\
use the PolyInterp and RatInterp functions in the Advanced\n\
Analysis Library.  The user generates a series of points to\n\
use as the known values in the array.  The points can be\n\
generated randomly or entered graphically with the graph\n\
cursor.  When the user clicks on the Interpolate button,\n\
the program generates an interpolated array of points and\n\
calculates the error for each point. The interpolated values\n\
are drawn in red and the error range is highlighted in gray.\n\
(The SpInterp function does not have an error estimate.)\n\
\n\
\n\
The 3 functions used within this example are discussed below.  \n\
\n\
PolyInterp() \n\
  Returns the interpolated y-value at the given x-value for the \n\
  unique polynomial of degree (Number of Elements - 1) passing \n\
  through the set of points (Array X, Array Y) that describe a \n\
  planar function.\n\
\n\
RatInterp() \n\
  Returns the interpolated y-value at the given x-value for the \n\
  unique rational function P(x)/Q(x) (where P and Q are \n\
  polynomials) passing through the set of points (Array X, Array Y).\n\
\n\
  This rational function is the unique function passing through \n\
  the given points such that: \n\
    if the number of elements is odd: \n\
      deg(P) = deg(Q) = (N-1)/2. \n\
    if the number of elements is even: \n\
      deg(Q) = N/2. \n\
      deg(P) = (N/2)-1. \n"
#define HELP_MSG_2 \
"\n\
    where deg() is the order of the polynomial function and N is \n\
    the number of elements. \n\
\n\
SpInterp() \n\
  Returns the Interpolated y-value at the given x-value for the \n\
  unique polynomial passing through the set of points (Array X, \n\
  Array Y) using a cubic spline interpolation. \n\
\n\
    Let: Y'' = Second Derivatives.  The interpolant on the interval \n\
    [ X[i], X[i+1] ] is specified as follows: \n\
\n\
    Interpolated Y Value = A*Y[i] + B*Y[i+1] + C*Y''[i] + D*Y''[i+1] \n\
\n\
      where   A = (X[i+1] - X Value) \n\
                   ----------------- \n\
                   (X[i+1] - X[i]) \n\
\n\
              B = 1 - A \n\
\n\
              C = (A**3 - A)*(X[i+1] - X[i])**2 \n\
                  ---------------------------- \n\
                               6 \n\
\n\
              D = (B**3 - B)*(X[i+1] - X[i])**2 \n\
                  ---------------------------- \n\
                               6 \n\
\n\
  The array of second derivatives is obtained from the function Spline." 
  
/*----------------------------------------------------------------------------*/
/* Includes                                                                   */
/*----------------------------------------------------------------------------*/
#include <utility.h>
#include <ansi_c.h>
#include <analysis.h>
#include <userint.h>
#include "interp.h"

/*----------------------------------------------------------------------------*/
/* Variables                                                                  */
/*----------------------------------------------------------------------------*/
int panelHandle;
double pulsebuf[101], pulsenegerr[101], pulseposerr[101];
double inputBuffer[101], outputBuffer[128], outputNegErr[101], outputPosErr[101];
double xArray[128], yArray[128], y2Array[128];
int manualModeActive=0;

int PointMark  = VAL_SOLID_SQUARE;
int PointColor = VAL_DK_BLUE;
int LineStyle  = VAL_THIN_LINE;
int LineColor  = VAL_DK_RED;
int ErrorColor = VAL_GRAY;

/*----------------------------------------------------------------------------*/
/* Main                                                                       */
/*----------------------------------------------------------------------------*/
int main (int argc, char *argv[])
{
    if (InitCVIRTE (0, argv, 0) == 0)    /* Needed if linking in external compiler; harmless otherwise */
        return -1;    /* out of memory */

    if ((panelHandle = LoadPanel (0, "interp.uir", PANEL)) < 0)
        return -1;
    
    SetCtrlAttribute (panelHandle, PANEL_STOPACQ, ATTR_DIMMED, 1);
    SetCtrlAttribute (panelHandle, PANEL_ACQ, ATTR_DIMMED, 0); 
    SetCtrlAttribute (panelHandle, PANEL_GRAPH, ATTR_NUM_CURSORS, 0);
    SetCtrlAttribute (panelHandle, PANEL_CHOOSEMSG, ATTR_VISIBLE, 0);
    
    DisplayPanel (panelHandle);
    RunUserInterface ();
    DiscardPanel (panelHandle);
    return 0;
}


/*----------------------------------------------------------------------------*/
/* Randomly Generate Points Button Callback                                   */
/*----------------------------------------------------------------------------*/
int CVICALLBACK GeneratePoints (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    unsigned short pointCount;
    int i, xval;
    
    switch (event) {
        case EVENT_COMMIT:
            GetCtrlVal (panelHandle, PANEL_POINTS, &pointCount);
            DeleteGraphPlot (panelHandle, PANEL_GRAPH, -1, VAL_IMMEDIATE_DRAW);
            
            for(i=0;i<101;i++) inputBuffer[i]=999; /* init pulse buffer */
            srand(Timer());

            /* Generate first and Last points and Plot */
            inputBuffer[0]   = rand()*40.0/(double)RAND_MAX - 20;
            PlotPoint (panelHandle, PANEL_GRAPH, 0, inputBuffer[0], PointMark, PointColor);

            inputBuffer[100] = rand()*40.0/(double)RAND_MAX - 20;
            PlotPoint (panelHandle, PANEL_GRAPH, 100, inputBuffer[100], PointMark, PointColor);
            
            /* Generate in between points and Plot */
            for (i=0;i<(pointCount-2);i++) {
                xval = rand()*100.0/(double)RAND_MAX;
                inputBuffer[xval] = rand()*40.0/(double)RAND_MAX - 20;
                PlotPoint (panelHandle, PANEL_GRAPH, xval, inputBuffer[xval], PointMark, PointColor);
            }
            
            /* Allow for Interpolation */
            SetCtrlAttribute (panelHandle, PANEL_INTERPOLATE, ATTR_DIMMED, 0);
            SetCtrlAttribute (panelHandle, PANEL_INTERPOLATE_2, ATTR_DIMMED, 0);  
            break;

    }
    return 0;
}

/*----------------------------------------------------------------------------*/
/* Manual Acquired Points - Button and Graph Callbacks                        */
/*----------------------------------------------------------------------------*/
int CVICALLBACK AcquirePoints (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    static int i;
    
    switch (event) {
        case EVENT_COMMIT:
        
            /* Clear Graph and Initialize the input data buffer */
            DeleteGraphPlot (panelHandle, PANEL_GRAPH, -1, VAL_IMMEDIATE_DRAW);
            for(i=0;i<101;i++) inputBuffer[i]=999; /* init pulse buffer */
            
            /* Activate the Graph callback and setup graph cursor */
            manualModeActive=1;
            SetCtrlAttribute (panelHandle, PANEL_GRAPH, ATTR_CTRL_MODE, VAL_NORMAL);
            SetCtrlAttribute (panelHandle, PANEL_GRAPH, ATTR_NUM_CURSORS, 1);
            SetCursorAttribute (panelHandle, PANEL_GRAPH, 1, ATTR_CROSS_HAIR_STYLE, VAL_SHORT_CROSS);
            SetGraphCursor (panelHandle, PANEL_GRAPH, 1, 0.0, 0.0);
            SetCtrlAttribute (panelHandle, PANEL_CHOOSEMSG, ATTR_VISIBLE, 1);
            
            /* Dim the Acquire button and activate the Done button */
            SetCtrlAttribute (panelHandle, PANEL_STOPACQ, ATTR_DIMMED, 0);
            SetCtrlAttribute (panelHandle, PANEL_ACQ, ATTR_DIMMED, 1);
            
            /* Disallow Interpolation */
            SetCtrlAttribute (panelHandle, PANEL_INTERPOLATE, ATTR_DIMMED, 1);
            SetCtrlAttribute (panelHandle, PANEL_INTERPOLATE_2, ATTR_DIMMED, 1);  
            
            break;
        case EVENT_LEFT_CLICK:

            break;
    }
    return 0;
}

/*----------------------------------------------------------------------------*/
/* StopAcquire                                                                */
/*----------------------------------------------------------------------------*/
int CVICALLBACK StopAcquire (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            /* Deactivate the Graph callback and its Graph cursors */
            manualModeActive=0;
            SetCtrlAttribute (panelHandle, PANEL_GRAPH, ATTR_CTRL_MODE, VAL_INDICATOR);
            SetCtrlAttribute (panelHandle, PANEL_GRAPH, ATTR_NUM_CURSORS, 0);

            /* Dim the Done button and activate the Acquire button */
            SetCtrlAttribute (panelHandle, PANEL_STOPACQ, ATTR_DIMMED, 1);
            SetCtrlAttribute (panelHandle, PANEL_ACQ, ATTR_DIMMED, 0);
            
            /* Allow for Interpolation */
            SetCtrlAttribute (panelHandle, PANEL_INTERPOLATE, ATTR_DIMMED, 0);
            SetCtrlAttribute (panelHandle, PANEL_INTERPOLATE_2, ATTR_DIMMED, 0);
            break;
    }
    return 0;
}

/*----------------------------------------------------------------------------*/
/* GraphCallback                                                              */
/*----------------------------------------------------------------------------*/
int CVICALLBACK GraphCallback (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    static double xval,yval;
    static int xint;
    
    switch (event) {
        case EVENT_VAL_CHANGED:
            if(manualModeActive) {
                /* Hide the Test message */
                SetCtrlAttribute (panelHandle, PANEL_CHOOSEMSG, ATTR_VISIBLE, 0);
                
                /* Save value into the input data buffer and Plot the point */
                GetGraphCursor (panelHandle, PANEL_GRAPH, 1, &xval, &yval);
                xint=(int)xval;
                if(xint<0) xint=0;
                inputBuffer[xint]=yval;
                PlotPoint (panelHandle, PANEL_GRAPH, xval, yval, PointMark, PointColor);
            }              
            
            break;
    }
    return 0;
}

/*----------------------------------------------------------------------------*/
/* Interpolate Button Callback                                                */
/*----------------------------------------------------------------------------*/
int CVICALLBACK Interpolate (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{

    int interpType, pointCount, i;
    double xValue, yValue = 0., yError;
    
    switch (event) {
        case EVENT_COMMIT:
            pointCount = 0;
            
            DeleteGraphPlot (panelHandle, PANEL_GRAPH, -1, VAL_IMMEDIATE_DRAW);
            
            /* Loop thru the input data points to find the data and plot their points */
            for (i=0;i<101;i++) {
                if (inputBuffer[i]!=999) {
                    xArray[pointCount] = i;
                    yArray[pointCount] = inputBuffer[i];
                    pointCount++;
                    
                    PlotPoint (panelHandle, PANEL_GRAPH, i, inputBuffer[i], PointMark, PointColor);
                }    
            }    
                        
            /* Interpolate for the other points */
            if (pointCount==0)
            	MessagePopup ("Interpolate", "You must generate at least 1 point before interpolating.");
            else {
                GetCtrlVal(panelHandle, PANEL_INTERPTYPE, &interpType);
                if (interpType==2) 
                    Spline(xArray, yArray, pointCount, 0.0, 0.0, y2Array);
                
                for (i=0;i<101;i++) {
                    xValue = i;
    
                    if (interpType==0) 
                        PolyInterp (xArray, yArray, pointCount, xValue, &yValue, &yError);
                    if (interpType==1) 
                        RatInterp (xArray, yArray, pointCount, xValue, &yValue, &yError);
                    if (interpType==2) 
                        SpInterp (xArray, yArray, y2Array, pointCount, xValue, &yValue);
                    
                    outputBuffer[i] = yValue;
                    
                    
                }    
                
                PlotWaveform (panelHandle, PANEL_GRAPH, outputBuffer, 101,
                              VAL_DOUBLE, 1.0, 0.0, 0.0, 1.0, LineStyle,
                              VAL_SOLID_CIRCLE, VAL_SOLID, 1, LineColor);
                    
            }    
            
            break;
    }
    return 0;
}   

/*----------------------------------------------------------------------------*/
/* Interpolate with error bound Button Callback,                              */
/* calculate estimated error and plot the data                                */
/*----------------------------------------------------------------------------*/
int CVICALLBACK Interpolate_2 (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    
    int interpType, pointCount, i;
    double xValue, yValue = 0., yError = 0.;
    
    switch (event) {
        case EVENT_COMMIT:
            pointCount = 0;
            
            DeleteGraphPlot (panelHandle, PANEL_GRAPH, -1, VAL_IMMEDIATE_DRAW);
            
            /* Loop thru the input data points to find the data and plot their points */
            for (i=0;i<101;i++) {
                if (inputBuffer[i]!=999) {
                    xArray[pointCount] = i;
                    yArray[pointCount] = inputBuffer[i];
                    pointCount++;
                    
                    PlotPoint (panelHandle, PANEL_GRAPH, i, inputBuffer[i], PointMark, PointColor);
                }    
            }    
                        
            /* Interpolate for the other points, calculate estimated error and plot the data */
            if (pointCount==0)
            	MessagePopup ("Interpolate", "You must generate at least 1 point before interpolating.");
            else {
                GetCtrlVal (panelHandle, PANEL_INTERPTYPE, &interpType);
                     
                for (i=0;i<101;i++) {
                    xValue = i;
    
                    if (interpType==0) 
                        PolyInterp (xArray, yArray, pointCount, xValue, &yValue, &yError);
                    if (interpType==1) 
                        RatInterp (xArray, yArray, pointCount, xValue, &yValue, &yError);
                    if (interpType==2) 
                        SpInterp (xArray, yArray, y2Array, pointCount, xValue, &yValue);
                    
                    outputBuffer[i] = yValue;
                    
                    if (interpType!=2) {
                        outputNegErr[i] = yValue+yError;
                        outputPosErr[i] = yValue-yError;   
                        PlotLine (panelHandle, PANEL_GRAPH, i, outputPosErr[i], i, outputNegErr[i], ErrorColor);
                     
                    } 
                     else{
                     MessagePopup ("Message",
                                          "Error Bound  is not a valid choice for Spline"); 
                       break;          
                              } 
                           
                }    
                
                PlotWaveform (panelHandle, PANEL_GRAPH, outputBuffer, 101,
                              VAL_DOUBLE, 1.0, 0.0, 0.0, 1.0, LineStyle,
                              VAL_SOLID_CIRCLE, VAL_SOLID, 1, LineColor);           
                    
            }    
            
            break;
    }
    return 0;
}

/*----------------------------------------------------------------------------*/
/* Quit                                                                       */
/*----------------------------------------------------------------------------*/
int CVICALLBACK Quit (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            QuitUserInterface (0);

            break;
    }
    return 0;
}

/*----------------------------------------------------------------------------*/
/* Help                                                                       */
/*----------------------------------------------------------------------------*/
int CVICALLBACK HelpCallback (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
	char msg[sizeof(HELP_MSG_1) + sizeof(HELP_MSG_2) + 1];
    switch (event) {
        case EVENT_RIGHT_CLICK:
        case EVENT_COMMIT:
        	strcpy(msg, HELP_MSG_1);
        	strcpy(msg + sizeof(HELP_MSG_1), HELP_MSG_2);
            MessagePopup ("Interpolation Example Program", msg);
        break;
    }
    return 0;
}


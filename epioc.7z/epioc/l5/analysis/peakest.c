/*****************************************************************/
/*                                                               */
/*  PowerFrequencyEstimate Example Program          */
/*  National Instruments                                         */
/*  August, 1995                                                 */
/*                                                               */
/*****************************************************************/
#define HELP_MSG \
"This program serves as an example use of the Spectrum and \n\
PowerFrequencyEstimate functions in the Advanced Analysis library.\n\
The top graph displays the input signal in the time domain and the\n\
bottom graph displays the power spectrum of the filtered input\n\
signal.\n\n\
You can use the mouse to move the vertical red graph cursor\n\
to an area that you wish to know the peak frequency and its power.\n\
These values are displayed in the Output Signal Info section."

#include <cvirte.h>     /* needed if linking executable in external compiler; harmless otherwise */
#include <userint.h>
#include <analysis.h>
#include <math.h>
#include "peakest.h"

#define NB_PTS      512
#define AMPLITUDE   2.282
#define FREQ        5.0/NB_PTS

double  gNoise;

static double SignalArray[NB_PTS];
static double NoiseArray[NB_PTS];
static int Handle;   

int main (int argc, char *argv[])
{
    if (InitCVIRTE (0, argv, 0) == 0)    /* Needed if linking in external compiler; harmless otherwise */
        return -1;    /* out of memory */
    
    if ((Handle = LoadPanel (0, "peakest.uir", PANEL)) < 0)
        return -1;
    DisplayPanel (Handle);
    RunUserInterface ();
	DiscardPanel (Handle);
    return 0;
}

int CVICALLBACK TimerFunction(int panel, int control, int event, void *callbackData,
                            int eventData1, int eventData2){
    int     Win, Signal, Scaling, Display;    
    double  df, Freq_Peak, Power_Peak,  Freq, Amp; 
    char    Unit[20]="V";        
    WindowConst WinConst;    
    static double phase=0.0;
    static double Converted_Spec[NB_PTS/2];    
    static double Auto_Spec[NB_PTS/2]; 
    
    
    if (event==EVENT_TIMER_TICK)
    {
        /* Generate Input Signal according the SIGNAL ring */
        GetCtrlVal(panel, PANEL_SIGNAL, &Signal);
        switch(Signal){
            case 0:
                SineWave (NB_PTS, AMPLITUDE, FREQ, &phase, SignalArray);
            break;
            case 1:
                SquareWave (NB_PTS, AMPLITUDE, FREQ, &phase, 50.0, SignalArray);
            break;
            case 2:
                TriangleWave (NB_PTS, AMPLITUDE, FREQ, &phase, SignalArray);
            break;
        }   
        
        /* Get current control information */
        GetCtrlVal (panel, PANEL_NOISE_LEVEL, &gNoise);
        gNoise/=100.0;
        WhiteNoise (NB_PTS, AMPLITUDE*gNoise, -1, NoiseArray);
        Add1D (SignalArray, NoiseArray, NB_PTS, SignalArray);
        
        /* Display Input Signal */
        DeleteGraphPlot (panel, PANEL_GRAPH1, -1, VAL_DELAYED_DRAW);
        PlotWaveform (panel, PANEL_GRAPH1, SignalArray, NB_PTS, VAL_DOUBLE, 1.0, 0.0, 0.0, 1/FREQ,
                                    VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, 1, VAL_DK_GREEN);

        /* Apply a Window according the WINDOW Ring              */
        /* The Win is apply to the input signal in Time Space    */
        /* Keep Window parameter for later use                   */
        GetCtrlVal(panel, PANEL_WINDOW, &Win);
        ScaledWindow (SignalArray, NB_PTS, Win, &WinConst);

        AutoPowerSpectrum (SignalArray, NB_PTS, 1/FREQ, Auto_Spec, &df);

        /* Get cursor position                              */
        /* Calculate the nearest peak frequency and power   */
        GetGraphCursor (panel, PANEL_GRAPH2, 1, &Freq, &Amp);
        PowerFrequencyEstimate (Auto_Spec, NB_PTS/2, Freq, WinConst, df, 7, &Freq_Peak, &Power_Peak);
        SetCtrlVal(panel, PANEL_POWER_PEAK, Power_Peak);
        SetCtrlVal(panel, PANEL_PEAK_FREQ, Freq_Peak);

        /* Get the scale information                                */
        /* Convert the spectrum and display the corresponding units */
        GetCtrlVal(panel, PANEL_SCALING, &Scaling);
        GetCtrlVal(panel, PANEL_DISPLAY, &Display);
        SpectrumUnitConversion (Auto_Spec, NB_PTS/2, 0, Scaling, Display, df, WinConst, Converted_Spec, Unit);
        SetCtrlVal(panel, PANEL_UNIT,Unit);

        /* Display the spectrum */
        DeleteGraphPlot (panel, PANEL_GRAPH2, -1, VAL_DELAYED_DRAW);
        PlotWaveform (panel, PANEL_GRAPH2, Converted_Spec, NB_PTS/4 ,VAL_DOUBLE, 1.0, 0.0, 0.0, df,
                                    VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, 1, VAL_DK_GREEN);
    }
    return(0);
}


int CVICALLBACK Quit(int panel, int control, int event, void *callbackData,
                        int eventData1, int eventData2){
    if (event==EVENT_COMMIT)    
        QuitUserInterface(0);
    return(0);
}

int CVICALLBACK Help (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2) {
    switch (event) {
        case EVENT_COMMIT:
            MessagePopup ("PowerFrequencyEstimate Example Program", HELP_MSG);
        break;
    }
    return 0;
}

/*----------------------------------------------------------------------------*/
/* Stability Test                                                             */
/*----------------------------------------------------------------------------*/
#define HELP_MSG \
"This example evaluates the stability of the system:\n\
     Y(z) = A(z)/B(z)\n\
and serves as an example of the Complex Polynomial Roots function.\n\
The coefficients for polynomials A(z) and B(z) are specified in left\n\
to right fashion with the highest order coefficients on the left side.\n\
\n\
For example: 0.5x^3 + 0.3x^2 + 1 is specified as\n\
\n\
    0.5 0.3 0.0 1.0\n\
\n\
Note it is not neccessary for the 0 to preceed the decimal seperator."

/*----------------------------------------------------------------------------*/
/* Includes                                                                   */
/*----------------------------------------------------------------------------*/
#include <ansi_c.h>
#include <formatio.h>
#include <analysis.h>
#include <userint.h>

#include "stabilty.h"

/*----------------------------------------------------------------------------*/
/* Variables                                                                  */
/*----------------------------------------------------------------------------*/
static int panelHandle;

/*----------------------------------------------------------------------------*/
/* Main                                                                       */
/*----------------------------------------------------------------------------*/
int main (int argc, char *argv[])
{
    if (InitCVIRTE (0, argv, 0) == 0)   /* Initialize CVI libraries */
        return -1;  /* out of memory */
    if ((panelHandle = LoadPanel (0, "stabilty.uir", PANEL)) < 0)
        return -1;
        
    SetCtrlVal (panelHandle, PANEL_ATEXT, "1.2 0.5");
    SetCtrlVal (panelHandle, PANEL_BTEXT, "1.1 0.25 0.3");
    
    DisplayPanel (panelHandle);
    RunUserInterface ();
	DiscardPanel (panelHandle);
    return 0;
}

/*----------------------------------------------------------------------------*/
/* SkipNonWhitespace                                                          */
/*----------------------------------------------------------------------------*/
static char * SkipNonWhitespace(char *string)
{
    char    *p=string;

    if (p)
        while (*p && !isspace((unsigned char)*p))
            p++;
    return p;
}


/*----------------------------------------------------------------------------*/
/* StabilityTest                                                              */
/*----------------------------------------------------------------------------*/
int StabilityTest(void)
{
    char Bdenom[100]= "";
    char Anum[100]= "";
    short numNum=0, numDen=0;
    size_t cnt =1;  
    int plthandl;  
    ssize_t minindex=0;
    double Minval=0;
    ssize_t maxindex=0;
    double Maxval=0;
    double *RealNum, *ImagNum, *RealDen = NULL, *ImagDen = NULL, *mag, *phase;
    ComplexNum *poles;
    ComplexNum *zeroes;
    double *Denominator;
    double *Numerator;
    char *strpntr;
    
    /* delete traces */
    DeleteGraphPlot (panelHandle, PANEL_PZGRAPH, -1, VAL_IMMEDIATE_DRAW); 
    
    /* Code to take text box input and convert to array parameters             */ 
    /* Anum and Bdenom can store 100 characters; which is what the maximum     */
    /* number of characters that can be entered into the text boxes is set to. */
    GetCtrlVal (panelHandle, PANEL_ATEXT, Anum);
    GetCtrlVal (panelHandle, PANEL_BTEXT, Bdenom);

    /* Determine number of parameters entered by counting white spaces and adding one */
    strpntr = "-1";
    while (strpntr != NULL)
    {
        numDen +=1;
        strpntr = SkipNonWhitespace (Bdenom+cnt);
        cnt =  strpntr-Bdenom+2;
        if (cnt > strlen(Bdenom))
            strpntr = NULL;
        
    }
    Denominator = malloc(numDen*sizeof(double));

    /* Determine number of parameters entered by counting white spaces and adding one */
    strpntr = "-1";
     cnt = 1;
    while (strpntr != NULL)
    {
        numNum +=1;                                                               
        strpntr = SkipNonWhitespace (Anum+cnt);
        cnt =  strpntr-Anum+2;
        if (cnt > strlen(Anum))
            strpntr = NULL;
        
    }
    Numerator = malloc(numNum*sizeof(double));

    /* Covert to floating point */
    Scan (Bdenom, "%s>%*f[x]",numDen, Denominator);
    Scan (Anum, "%s>%*f[x]",numNum, Numerator);

    /* A physical system must have more poles than zeroes */

    if  (numDen >= numNum)
    {

        /* Compute root locations poles */   
        if (numDen > 1)
        {
            poles = malloc((numDen-1)*sizeof(ComplexNum));
            CxPolyRoots (Denominator, numDen, poles); 
            ImagDen = malloc((numDen-1)*sizeof(double));
            RealDen = malloc((numDen-1)*sizeof(double));

            for (cnt = 0; cnt < numDen-1; cnt++)
                {
                ImagDen[cnt] = poles[cnt].imaginary;
                RealDen[cnt] = poles[cnt].real;
                }
    
            mag = malloc((numDen-1)*sizeof(double));
            phase = malloc((numDen-1)*sizeof(double));
        }
        else /* poles = 0 + 0i */
        {
            poles = malloc(sizeof(ComplexNum));
            poles[0].real = 0.0;
            poles[0].imaginary = 0.0;
            mag = malloc(sizeof(double));
            phase = malloc(sizeof(double));
        }
    
        /* zeroes */
        if (numNum > 1)
        {
            zeroes = malloc((numNum-1)*sizeof(ComplexNum));
            CxPolyRoots (Numerator, numNum, zeroes);
            ImagNum = malloc((numNum-1)*sizeof(double));
            RealNum = malloc((numNum-1)*sizeof(double));
    
            for (cnt = 0; cnt < numNum-1; cnt++)
                {
                ImagNum[cnt] = zeroes[cnt].imaginary;
                RealNum[cnt] = zeroes[cnt].real;
                }

        }
        else /* zeroes = 0+0i */
        {
            zeroes = malloc(sizeof(ComplexNum));
            zeroes[0].real = 0.0;
            zeroes[0].imaginary = 0.0;
            ImagNum = malloc(sizeof(double));
            RealNum = malloc(sizeof(double));
    
        }
    
        /* System is stable if |poles| <= 1.  To compute magnitude we will 1st extract the imaginary and real component*/
        /* and then evaluate magnitude of poles.                                                                       */
        /* ImagNum, RealNum, ImagDen and RealDen contain the imaginary and real components of the zeroes and poles.    */
        ToPolar1D (RealDen, ImagDen, numDen-1, mag, phase); 
        MaxMin1D (mag, numDen-1, &Maxval, &maxindex, &Minval, &minindex);
        SetCtrlVal (panelHandle, PANEL_LED, (Maxval > 1.0));
    
        /* Plot poles zeroes and a circle around |<x,y>| = 1; */
        PlotOval (panelHandle, PANEL_PZGRAPH, -1, -1, 1, 1, VAL_BLACK,VAL_TRANSPARENT);
        PlotLine (panelHandle, PANEL_PZGRAPH, -2, 0, 2, 0, VAL_BLACK);
        PlotLine (panelHandle, PANEL_PZGRAPH, 0, -2, 0, 2, VAL_BLACK);
    
        /* Plot Data */
        plthandl = PlotXY (panelHandle, PANEL_PZGRAPH, RealDen, ImagDen,
                           ((numDen >1)?(numDen-1):1) , VAL_DOUBLE, VAL_DOUBLE, VAL_SCATTER,
                           VAL_X, VAL_SOLID, 1, VAL_DK_RED);
               
        plthandl = PlotXY (panelHandle, PANEL_PZGRAPH, RealNum,
                           ImagNum, ((numNum >1)?(numNum-1):1),
                           VAL_DOUBLE, VAL_DOUBLE, VAL_SCATTER,
                           VAL_EMPTY_CIRCLE, VAL_SOLID, 1,
                           VAL_DK_GREEN);
                   

        /* free dynamically allocated memory */
        free(mag);
        free(phase);
        free(ImagNum);
        free(RealNum);
        free(poles);
        free(zeroes);
		free(ImagDen);
		free(RealDen);
    }
    else MessagePopup("Error!","Number of B(z) coefficients must be greater or equal to number of A(z) coefficients");
    
    free(Denominator);
    free(Numerator);
    
    return 0;
}


/*----------------------------------------------------------------------------*/
/* StabilityTest                                                              */
/*----------------------------------------------------------------------------*/
int CVICALLBACK Start (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            StabilityTest();
            break;       
    }                                            
    return 0;
}

/*----------------------------------------------------------------------------*/
/* Help                                                                       */
/*----------------------------------------------------------------------------*/
int CVICALLBACK Help (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_RIGHT_CLICK:
        case EVENT_COMMIT:
            MessagePopup ("Stability Test Example", HELP_MSG);
        break;
    }
    return 0;
}

/*----------------------------------------------------------------------------*/
/* Quit                                                                       */
/*----------------------------------------------------------------------------*/
int CVICALLBACK Quit (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            QuitUserInterface(0);

            break;
    }
    return 0;
}

/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  MAINPNL                         1
#define  MAINPNL_TEXTMSG1                2
#define  MAINPNL_SIG1POINTS              3       /* callback function: Getsig1points */
#define  MAINPNL_SIG1CYCLES              4       /* callback function: Getsig1cycles */
#define  MAINPNL_SIG1PHASE               5       /* callback function: Getsig1phase */
#define  MAINPNL_SIG1NOISE               6       /* callback function: Getsig1noise */
#define  MAINPNL_SIG1NOISEAMP            7       /* callback function: Getsig1noiseamp */
#define  MAINPNL_SIG1WAVETYPE            8       /* callback function: Getsig1wavetype */
#define  MAINPNL_DECORATION              9
#define  MAINPNL_TEXTMSG2                10
#define  MAINPNL_SIG2POINTS              11      /* callback function: Getsig2points */
#define  MAINPNL_SIG2CYCLES              12      /* callback function: Getsig2cycles */
#define  MAINPNL_SIG2PHASE               13      /* callback function: Getsig2phase */
#define  MAINPNL_SIG2NOISE               14      /* callback function: Getsig2noise */
#define  MAINPNL_SIG2NOISEAMP            15      /* callback function: Getsig2noiseamp */
#define  MAINPNL_SIG2WAVETYPE            16      /* callback function: Getsig2wavetype */
#define  MAINPNL_DECORATION_2            17
#define  MAINPNL_CHECKBOX                18      /* callback function: SetAutoGenerate */
#define  MAINPNL_GENERATESIG1            19      /* callback function: Generatesig1 */
#define  MAINPNL_HELP                    20      /* callback function: HelpCallback */
#define  MAINPNL_QUIT                    21      /* callback function: Quit */
#define  MAINPNL_SIG1GRAPH               22
#define  MAINPNL_SIG2GRAPH               23
#define  MAINPNL_CONVGRAPH               24
#define  MAINPNL_DECONVGRAPH             25
#define  MAINPNL_WARNINGMSG              26


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */ 

int  CVICALLBACK Generatesig1(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig1cycles(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig1noise(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig1noiseamp(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig1phase(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig1points(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig1wavetype(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig2cycles(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig2noise(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig2noiseamp(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig2phase(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig2points(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Getsig2wavetype(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK HelpCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Quit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SetAutoGenerate(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif

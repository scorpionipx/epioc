/*****************************************************************/
/*                                                               */
/*  Mode Function Example Program                                */
/*                                                               */
/*****************************************************************/
#define HELP_MSG \
  "This program serves as an example to illustrate the use of the \n"\
  "Histogram and Mode functions in the Analysis libraries.  The mode \n"\
  "value is defined as the value that most often occurs in a given set \n"\
  "of samples."

#include <cvirte.h>     /* needed if linking executable in external compiler; harmless otherwise */
#include <formatio.h>
#include <analysis.h>
#include <userint.h>
#include "mode.h"

static int panelHandle;

/*****************************************************************/
/* Main                                                          */
/*****************************************************************/

int main (int argc, char *argv[])
{
    if (InitCVIRTE (0, argv, 0) == 0)    /* Needed if linking in external compiler; harmless otherwise */
        return -1;    /* out of memory */
    
    if ((panelHandle = LoadPanel (0, "mode.uir", PANEL)) < 0)
        return -1;
    DisplayPanel (panelHandle);
    RunUserInterface ();
    DiscardPanel (panelHandle);
    return 0;
}

/*****************************************************************/
/* Quit Button Callback                                          */
/*****************************************************************/
int CVICALLBACK Shutdown (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_COMMIT:
            QuitUserInterface (0);
            break;
    }
    return 0;
}

/*****************************************************************/
/* Plot Button Callback - plots the histogram and calculates mode*/
/*****************************************************************/
int CVICALLBACK Plot (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{

    static double DataArray[5];
    static int intervals;
    static ssize_t hist[101];
    static double axis[101];
    double modeValue;
    static double max, min;
    static ssize_t imax, imin;
    static int i;
    static char message[64];
    
    switch (event) {
        case EVENT_COMMIT:

            /* Get the array values from the UIR */
            GetCtrlVal (panel, PANEL_INTERVALS, &intervals);
            GetCtrlVal (panel, PANEL_Data0, &DataArray[0]);
            GetCtrlVal (panel, PANEL_Data1, &DataArray[1]);
            GetCtrlVal (panel, PANEL_Data2, &DataArray[2]);
            GetCtrlVal (panel, PANEL_Data3, &DataArray[3]);
            GetCtrlVal (panel, PANEL_Data4, &DataArray[4]);

            /* Get the min and max values in the array */
            MaxMin1D (DataArray,5, &max, &imax, &min, &imin);
            
            /* Calculate Mode and Histogram */
            /* Round max up and round min down to include all points, double precision can be funny */
            Mode (DataArray, 5, min-1, max+1, intervals, &modeValue);
            Histogram (DataArray, 5, min-1, max+1, hist, axis, intervals);
            
            /* Display the Min and Max used for the Histogram function */
            SetCtrlVal (panel, PANEL_HISTMIN, min-1);
            SetCtrlVal (panel, PANEL_HISTMAX, max+1);
            
            /* Display the Mode and the Histogram */
            SetCtrlVal (panel, PANEL_MODE, modeValue);
            SetAxisRange (panel, PANEL_GRAPH, VAL_MANUAL, min-1, max+1, VAL_MANUAL, 0, max+1);
            DeleteGraphPlot (panel, PANEL_GRAPH, -1, VAL_DELAYED_DRAW);
            PlotXY (panel, PANEL_GRAPH, axis,  hist, intervals, 
                VAL_DOUBLE, VAL_SSIZE_T, VAL_VERTICAL_BAR, VAL_EMPTY_SQUARE, VAL_SOLID, 1, VAL_RED);
                
            /* Display the Histogram Text */
            for (i=0;i<intervals; i++) {
                if (hist[i]>0) {
                    Fmt(message,"Center at");
                    PlotText (panel, PANEL_GRAPH, axis[i]-0.5, (double)hist[i]+0.6, 
                        message, VAL_APP_META_FONT, VAL_BLUE, VAL_TRANSPARENT);
                
                    Fmt(message,"%f", axis[i]);
                    PlotText (panel, PANEL_GRAPH, axis[i]-0.25, (double)hist[i]+0.25, 
                        message, VAL_APP_META_FONT, VAL_BLUE, VAL_TRANSPARENT);
                }        
            }          
            break;
    }
    return 0;
}


/*****************************************************************/
/* Help Button Callback                                          */
/*****************************************************************/
int CVICALLBACK HelpCallback (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    switch (event) {
        case EVENT_RIGHT_CLICK:
        case EVENT_COMMIT:
            MessagePopup ("Correlation Function Example Program",HELP_MSG);
        break;
    }
    return 0;
}

/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                           1
#define  PANEL_HELP                      2       /* callback function: Help */
#define  PANEL_GRAPH2                    3
#define  PANEL_QUIT                      4       /* callback function: Quit */
#define  PANEL_NOISE_LEVEL               5
#define  PANEL_WINDOW                    6
#define  PANEL_SCALING                   7
#define  PANEL_PEAK_FREQ                 8
#define  PANEL_DISPLAY                   9
#define  PANEL_POWER_PEAK                10
#define  PANEL_SIGNAL                    11
#define  PANEL_GRAPH1                    12
#define  PANEL_DECORATION                13
#define  PANEL_DECORATION_2              14
#define  PANEL_DECORATION_4              15
#define  PANEL_DECORATION_5              16
#define  PANEL_UNIT                      17
#define  PANEL_TEXTMSG_2                 18
#define  PANEL_UNIT_2                    19
#define  PANEL_TEXTMSG_4                 20
#define  PANEL_TEXTMSG_7                 21
#define  PANEL_TEXTMSG_6                 22
#define  PANEL_TEXTMSG                   23
#define  PANEL_TEXTMSG_3                 24
#define  PANEL_TIMER                     25      /* callback function: TimerFunction */


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */ 

int  CVICALLBACK Help(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Quit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK TimerFunction(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif

#include <ansi_c.h>
#include <analysis.h>
#include <cvirte.h>		
#include <userint.h>
#include "lab_4uir.h"


#define POINTS_TO_PLOT 200

static int panelHandle;
static double calculated_points[1][POINTS_TO_PLOT];
static double fancy_calculated_points[1][POINTS_TO_PLOT];


int __stdcall WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
					   LPSTR lpszCmdLine, int nCmdShow)
{
	if (InitCVIRTE (hInstance, 0, 0) == 0)
		return -1;	/* out of memory */
	if ((panelHandle = LoadPanel (0, "lab_4uir.uir", PANEL)) < 0)
		return -1;
	DisplayPanel (panelHandle);
	
    double zero = 0.0;
	
	
	//SineWave (200, 1.0, 60, &zero, &calculated_points);
	
	
	int y[200];
	for(int i=0;i < 200; i++)
		y[i] = i;
	
	//PlotWaveform (panelHandle, PANEL_GRAPH,(int)calculated_points, 200, VAL_INTEGER, 1.0, 0.0, 0.0, 1.0, VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, 1, VAL_RED);
				
	
	
	DeleteGraphPlot (panelHandle, PANEL_GRAPH, -1, VAL_IMMEDIATE_DRAW);
	
	SinePattern (200, 1.0, 0.0, 4, calculated_points[0]);
	
	PlotWaveform (panelHandle, PANEL_GRAPH, calculated_points, 200, VAL_DOUBLE, 1.0, 0.0, 0.0, 1.0, VAL_THIN_LINE, VAL_EMPTY_SQUARE,
				  VAL_SOLID, 1, VAL_RED);
	
	
	
	
	
	RunUserInterface ();
	DiscardPanel (panelHandle);
	return 0;
}

int CVICALLBACK fPanel (int panel, int event, void *callbackData,
						int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_GOT_FOCUS:

			break;
		case EVENT_LOST_FOCUS:

			break;
		case EVENT_CLOSE:
			QuitUserInterface (0);
			break;
	}
	return 0;
}

void ClearGraph(void)
{
   printf("ClearGraph called\n");
   DeleteGraphPlot (panelHandle, PANEL_GRAPH, -1, VAL_IMMEDIATE_DRAW);
}

void RedrawGraph(void)  
{
   printf("RedrawGraph called\n");
   ClearGraph();
   
   int num_of_per;
   GetCtrlVal (panelHandle, PANEL_NUMERICKNOB, &num_of_per);
   printf("Knobvalue: %d", num_of_per);
   
   SinePattern (200, 1.0, 0.0, num_of_per, calculated_points[0]);
	
	PlotWaveform (panelHandle, PANEL_GRAPH, calculated_points, 200, VAL_DOUBLE, 1.0, 0.0, 0.0, 1.0, VAL_THIN_LINE, VAL_EMPTY_SQUARE,
				  VAL_SOLID, 1, VAL_RED);
   
}


void DrawFancyGraph(void)
{
	
   printf("DrawFancyGraph called\n");
   ClearGraph();
   int num_of_per;
   GetCtrlVal (panelHandle, PANEL_NUMERICKNOB, &num_of_per);
   printf("Knobvalue: %d", num_of_per);
   
   for(int i=0;i< POINTS_TO_PLOT;i++)
   {
	   fancy_calculated_points[0][i] = 0;
   }
   
   for(int c=0; c< num_of_per; c++)
   {
	   	SinePattern (200, 1.0, 0.0, c + 1, calculated_points[0]); 
	
		for(int i=0;i< POINTS_TO_PLOT;i++)
	   {
		   calculated_points[0][i] = calculated_points[0][i] / (1 + (2 * c));
	   }
		
		PlotWaveform (panelHandle, PANEL_GRAPH, calculated_points, 200, VAL_DOUBLE, 1.0, 0.0, 0.0, 1.0, VAL_THIN_LINE, VAL_EMPTY_SQUARE,
				  VAL_SOLID, 1, VAL_WHITE);
		
		for(int i=0;i< POINTS_TO_PLOT;i++)
   		{
	   		fancy_calculated_points[0][i] += calculated_points[0][i];
   		}
   }
   PlotWaveform (panelHandle, PANEL_GRAPH, fancy_calculated_points, 200, VAL_DOUBLE, 1.0, 0.0, 0.0, 1.0, VAL_THIN_LINE, VAL_EMPTY_SQUARE,
				  VAL_SOLID, 1, VAL_RED);
}


int CVICALLBACK fGenerate (int panel, int control, int event,
						   void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:

			{
				printf("Button pressed\n");
				DrawFancyGraph();
				break;
			}
	}
	return 0;
}

int CVICALLBACK fNumeric (int panel, int control, int event,
						  void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			{
				
				printf("Graphjauto generated!\n");
				RedrawGraph();
				
   
   				SinePattern (200, 1.0, 0.0, 4, calculated_points[0]);
	
				PlotWaveform (panelHandle, PANEL_GRAPH, calculated_points, 200, VAL_DOUBLE, 1.0, 0.0, 0.0, 1.0, VAL_THIN_LINE, VAL_EMPTY_SQUARE,
				  VAL_SOLID, 1, VAL_RED);
				break;
			}
	}
	return 0;
}

int CVICALLBACK fGraph (int panel, int control, int event,
						void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:

			{
				break;
			}
	}
	return 0;
}
